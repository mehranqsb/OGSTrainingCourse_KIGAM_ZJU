# SPDX-FileCopyrightText: Copyright (c) OpenGeoSys Community (opengeosys.org)
# SPDX-License-Identifier: BSD-3-Clause

# source: https://github.com/python/typing/issues/270#issuecomment-1344537820

import functools
import warnings
from collections.abc import Callable
from typing import Concatenate, ParamSpec, TypeVar

S = TypeVar("S")
P = ParamSpec("P")
T = TypeVar("T")


# developer note:
# if you use this decorator make sure, that the return type of the copied
# function is static. I.e. `plt.Figure` is a decorated class, which receives
# some dynamic docstring substitution from matplotlib, and will not correctly be
# inferred by linters (shows Unknown instead). But if you type hint with
# `matplotlib.figure.Figure` it works as it seemingly takes the Figure class
# without executing the decorator (just a guess).
def copy_function_signature(
    source: Callable[P, T],
) -> Callable[[Callable], Callable[P, T]]:
    def wrapper(target: Callable) -> Callable[P, T]:
        @functools.wraps(source)
        def wrapped(*args: P.args, **kwargs: P.kwargs) -> T:
            return target(*args, **kwargs)

        # remove first param entry
        doc = wrapped.__doc__
        if doc is not None and ":param" in doc:
            param1_start = doc.index(":param")
            param1_end = param1_start + doc[param1_start:].index("\n")
            wrapped.__doc__ = doc[:param1_start] + doc[param1_end:]

        return wrapped

    return wrapper


def copy_method_signature(
    source: Callable[Concatenate[S, P], T],
) -> Callable[[Callable], Callable[Concatenate[S, P], T]]:

    def wrapper(target: Callable) -> Callable[Concatenate[S, P], T]:

        @functools.wraps(source)
        def wrapped(self: S, *args: P.args, **kwargs: P.kwargs) -> T:
            return target(self, *args, **kwargs)

        # remove first param entry
        doc = wrapped.__doc__
        if doc is not None and ":param" in doc:
            param1_start = doc.index(":param")
            param1_end = param1_start + doc[param1_start:].index("\n")
            wrapped.__doc__ = doc[:param1_start] + doc[param1_end:]

        return wrapped

    return wrapper


def deprecated(
    msg: str = "",
) -> Callable[[Callable], Callable[P, T]]:
    "Use this decorator to mark functions as deprecated."

    def wrapper(func: Callable) -> Callable[P, T]:

        @functools.wraps(func)
        def new_func(*args: P.args, **kwargs: P.kwargs) -> T:
            warnings.warn(
                f"Call to a deprecated function {func.__name__}. {msg}",
                category=DeprecationWarning,
                stacklevel=2,
            )
            return func(*args, **kwargs)

        return new_func

    return wrapper
