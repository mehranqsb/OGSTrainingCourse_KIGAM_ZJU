# SPDX-FileCopyrightText: Copyright (c) OpenGeoSys Community (opengeosys.org)
# SPDX-License-Identifier: BSD-3-Clause

import logging as log
from importlib.util import find_spec
from sys import stdout

if find_spec("ifm") is None:
    msg = "Could not import ifm. A working FEFLOW Python setup is required!"
    raise ImportError(msg)

from ._feflowlib import read_feflow
from ._tools import assign_bulk_ids, remove_bulk_ids
from .feflow_model import FeflowModel

__all__ = ["FeflowModel", "assign_bulk_ids", "read_feflow", "remove_bulk_ids"]

# log configuration
log.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    encoding="utf-8",
    level=log.WARN,
    stream=stdout,
    datefmt="%d.%m.%Y %H:%M:%S",
)
