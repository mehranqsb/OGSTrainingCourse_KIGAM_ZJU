# SPDX-FileCopyrightText: Copyright (c) OpenGeoSys Community (opengeosys.org)
# SPDX-License-Identifier: BSD-3-Clause

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from ogstools.definitions import MATERIALS_DIR
from ogstools.materiallib.schema.process_schema import PROCESS_SCHEMAS

from .material import Material

logger = logging.getLogger(__name__)


class MaterialManager:
    """
    Manager for material definitions loaded from a repository of YAML files.

    A MaterialManager can be constructed in two ways:

    1. **From a repository directory** (default):
       If no materials are provided, all YAML files in the given
       `data_dir` are parsed into Material objects and stored in
       `materials_db`.

    2. **From pre-filtered materials**:
       If a dictionary of `Material` objects is passed via `materials`,
       the manager is created directly from these. This is typically
       used internally when creating filtered views.

    Once constructed, a MaterialManager can:
    - provide access to the stored materials

    - filter materials according to a process schema, subdomain mapping,
      and/or fluid assignments

    - represent the filtered material set as a new MaterialManager.

    """

    def __init__(
        self,
        data_dir: Path | str | None = None,
        materials: dict[str, Material] | None = None,
        subdomain_ids: dict[str, int] | None = None,
        process: str | None = None,
    ):
        """
        Initialize a MaterialManager instance.

        Parameters
        ----------
        data_dir : Path | str | None
            Directory containing the repository of material YAML files.
            Defaults to `ot.definitions.MATERIALS_DIR`. Only used if no `materials`
            are passed.
        materials : dict[str, Material] | None
            Pre-loaded material dictionary. If None, materials are loaded
            from the repository directory. If provided, these materials are
            used as-is without accessing the repository (commonly from filtering).
        subdomain_ids : dict[str, int] | None
            Mapping of subdomain names to material IDs.
        process : str | None
            Process type used for filtering, if applicable.

        Notes
        -----
        - If `materials` is None, the instance represents the **full material
          repository** loaded from the given directory.
        - If `materials` is provided, the instance represents a **filtered view**
          and does not perform any additional repository access.
        """

        self.data_dir = Path(data_dir or MATERIALS_DIR)
        self.materials_db: dict[str, Material] = materials or {}
        self.subdomain_ids: dict[str, int] = subdomain_ids or {}
        self.fluids: dict[str, Material] = {}
        self.process = process

        if materials is None:  # only load from repository if not provided
            logger.info("Loading materials from repository: %s", self.data_dir)
            self._load_materials()
            logger.debug("Materials loaded: %s", list(self.materials_db.keys()))
        else:
            logger.debug("Using provided materials: %s", list(materials.keys()))

    def set_material(self, file_path: str | Path) -> None:
        """Write a material entry based of one yaml file."""
        material = Material.from_file(file_path)
        if material is None:
            return
        self.materials_db[material.name] = material

    # ------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------
    def _load_materials(self) -> None:
        yaml_files = list(self.data_dir.glob("*.yml")) + list(
            self.data_dir.glob("*.yaml")
        )
        if not yaml_files:
            msg = f"No YAML files found in {self.data_dir}"
            raise FileNotFoundError(msg)

        for file_path in yaml_files:
            material = Material.from_file(file_path)
            if material is not None:
                self.materials_db[material.name] = material

    # ------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------
    def get_material(self, name: str) -> Material:
        """
        Retrieve a material from the repository by name.
        """
        if name not in self.materials_db:
            msg = f"Material '{name}' not found in repository."
            raise ValueError(msg)
        return self.materials_db[name]

    def _list_materials(self) -> list[str]:
        return list(self.materials_db.keys())

    # ------------------------------------------------------------
    # Filtering
    # ------------------------------------------------------------
    def filter(
        self,
        process: str,
        subdomains: list[dict[str, Any]],
        fluids: dict[str, str] | None = None,
    ) -> MaterialManager:
        """
        Create a filtered view of the materials for a given process.

        Filtering is based on:
        - a process schema,
        - subdomain assignments (mapping subdomain names to one or more material IDs),
        - optional fluid phase materials.

        Parameters
        ----------
        process : str
            The process name to filter by.
        subdomains : list[dict[str, Any]]
            A list of dictionaries, each containing the material name,
            a subdomain name, and one or more material IDs.
        fluids : dict[str, str] | None
            A dictionary mapping phase types to material names.

        Returns
        -------
        MaterialManager
            A new MaterialManager instance containing only the filtered
            materials. This new instance does not access the repository;
            it reuses the already loaded Material objects.
        """
        schema = PROCESS_SCHEMAS.get(process)
        if schema is None:
            msg = f"No process schema found for '{process}'"
            raise ValueError(msg)

        filtered: dict[str, Material] = {}
        subdomain_ids: dict[str, int] = {}

        # Solids (subdomains)
        for entry in subdomains:
            name = entry["material"]
            mat = self.get_material(name).copy()
            mat.filter_process(schema)

            subdomain_name = entry["subdomain"]
            mat_ids = entry["material_ids"]
            if isinstance(mat_ids, int):
                mat_ids = [mat_ids]

            for mat_id in mat_ids:
                # if only one ID, keep the plain subdomain name
                # if multiple IDs, disambiguate by appending the ID
                key = (
                    subdomain_name
                    if len(mat_ids) == 1
                    else f"{subdomain_name}_{mat_id}"
                )
                filtered[key] = mat
                subdomain_ids[key] = mat_id

        # Fluids
        fluid_materials: dict[str, Material] = {}
        for phase_type, mat_name in (fluids or {}).items():
            fluid = self.get_material(mat_name).copy()
            fluid.filter_process(schema)
            fluid_materials[phase_type] = fluid

        return MaterialManager(
            data_dir=self.data_dir,
            materials=filtered,
            subdomain_ids=subdomain_ids,
            process=process,
        )._with_fluids(fluid_materials)

    def _with_fluids(self, fluids: dict[str, Material]) -> MaterialManager:
        """
        Internal helper to attach fluid materials to a filtered manager.
        """
        self.fluids = fluids
        return self

    def _list_ids(self) -> list[int]:
        """
        Return a list of material IDs for the subdomains.
        """
        return list(self.subdomain_ids.values())

    def _list_subdomains(self) -> list[str]:
        """
        Return a list of subdomain names managed by this instance.
        """
        return list(self.subdomain_ids.keys())

    # ------------------------------------------------------------
    # Representation
    # ------------------------------------------------------------
    def __repr__(self) -> str:
        lines = [f"<MaterialManager with {len(self.materials_db)} materials>"]

        # Solids / medium materials
        if self.subdomain_ids:
            lines.append(
                f"  ├─ {len(self.subdomain_ids)} solid material entries mapped to material_ids:"
            )
            for name in sorted(
                self.subdomain_ids, key=lambda n: self.subdomain_ids.get(n, 999)
            ):
                mat = self.materials_db.get(name)
                mid = self.subdomain_ids.get(name, "?")
                lines.append(
                    f"  │   [{mid}] {name}: '{mat.name if mat else '?'}'"
                )
        else:
            lines.append("  ├─ No solid or medium materials defined")

        # Fluids: prefer explicit self.fluids if present
        if self.fluids:
            lines.append(f"  ├─ {len(self.fluids)} fluid materials:")
            for phase_type, mat in self.fluids.items():
                lines.append(f"  │   {phase_type}: {mat.name}")
        else:
            # fallback: derive fluids from materials_db
            fluid_keys = [
                k for k in self.materials_db if k not in self.subdomain_ids
            ]
            if fluid_keys:
                lines.append(f"  ├─ {len(fluid_keys)} fluid materials:")
                for phase_type in fluid_keys:
                    mat = self.materials_db[phase_type]
                    lines.append(f"  │   {phase_type}: {mat.name}")
            else:
                lines.append("  └─ No fluid materials assigned")

        return "\n".join(lines)
