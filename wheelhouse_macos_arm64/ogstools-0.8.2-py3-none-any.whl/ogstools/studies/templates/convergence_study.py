# SPDX-FileCopyrightText: Copyright (c) OpenGeoSys Community (opengeosys.org)
# SPDX-License-Identifier: BSD-3-Clause

# ---
# jupyter:
#   kernelspec:
#     display_name: .venv
#     language: python
#     name: python3
# ---
# %% tags=["remove_cell"]
# mypy: ignore-errors
#
# This script is intended to be run via papermill with custom parameters.

# %% tags=["parameters", "remove_cell"]
# These are placeholders and get replaced with injected parameters.
mesh_paths = [""]
timevalue: float = 0.0
variable_name: str = ""
refinement_ratio: float = 2.0
reference_solution_path = None

# %% tags=["remove_input"]
# Import required modules and customize plot settings.
# pylint:disable=C0413
import numpy as np
import pyvista as pv
from IPython.display import display

import ogstools as ot
from ogstools import studies

ot.plot.setup.reset()
ot.plot.setup.show_element_edges = True
ot.plot.setup.combined_colorbar = False


def _show_with_alt(fig: object, alt: str) -> None:
    """Display a matplotlib figure with alt text, then close it."""
    if isinstance(fig, ot.plot.contourplots.plt.Figure):
        display(fig, metadata={"image/png": {"alt": alt}})
        ot.plot.contourplots.plt.close(fig)


# %% tags=["remove_input"]
# Here, the meshes are read, a Variable object is created from the variable
# name and the Richardson extrapolation calculated.
# The 3 finest meshes of those provided will be used for the Richardson
# extrapolation.

mesh_series = [ot.MeshSeries(mesh_path) for mesh_path in mesh_paths]
timestep_sizes = [np.mean(np.diff(ms.timevalues)) for ms in mesh_series]
meshes = [ms.mesh(ms.closest_timestep(timevalue)) for ms in mesh_series]
topology: pv.UnstructuredGrid = meshes[-3]
variable = ot.variables.Variable.find(variable_name, meshes[0])
richardson = studies.convergence.richardson_extrapolation(
    meshes, variable, topology, refinement_ratio
)

# %% [markdown]
# ## Grid convergence
#
# If the shown values are approximately 1, this means that the results are in
# asymptotic range of convergence.

# %% tags=["remove_input"]
fig = ot.plot.contourf(richardson, "grid_convergence")
_show_with_alt(
    fig, "Contour plot of the grid convergence index across the mesh."
)

# %% [markdown]
# ## Grid comparison
#
# Visualizing the requested mesh variable on the 3 finest discretizations:

# %% tags=["remove_input"]
fig = ot.plot.contourf(meshes[-3:], variable)
_show_with_alt(
    fig,
    f"Contour plots of {variable.output_name} on the 3 finest discretizations.",
)

# %% [markdown]
# ## Richardson extrapolation
#
# Visualizing the Richardson extrapolation of the requested mesh variable.
# If a reference solution is provided, the difference between the two is shown
# as well. Otherwise the difference between the finest discretization and
# the Richardson extrapolation is shown.

# %% tags=["remove_input"]
fig = ot.plot.contourf(richardson, variable)
_show_with_alt(
    fig,
    f"Contour plot of the Richardson extrapolation of {variable.output_name}.",
)

data_key = variable.data_name
if reference_solution_path is None:
    diff_mesh = ot.mesh.difference(
        richardson, topology.sample(meshes[-1]), variable
    )
    fig = ot.plot.contourf(diff_mesh, variable)
    _show_with_alt(
        fig,
        f"Contour plot of the difference in {variable.output_name} between "
        "the finest discretization and the Richardson extrapolation.",
    )
else:
    ms = ot.MeshSeries(reference_solution_path)
    timestep = ms.closest_timestep(timevalue)
    reference_solution = topology.sample(ms.mesh(timestep))
    diff_mesh = ot.mesh.difference(reference_solution, richardson, variable)
    fig = ot.plot.contourf(diff_mesh, variable)
    _show_with_alt(
        fig,
        f"Contour plot of the difference in {variable.output_name} between "
        "the reference solution and the Richardson extrapolation.",
    )

# %% [markdown]
# ## Convergence metrics

# %% tags=["remove_input"]
metrics = studies.convergence.convergence_metrics(
    meshes, richardson, variable, timestep_sizes
)
metrics.style.format("{:,.5g}").hide()

# %% [markdown]
# ## Relative errors

# %% tags=["remove_input"]
ot.plot.contourplots.plt.rcdefaults()
fig = studies.convergence.plot_convergence_errors(metrics)
_show_with_alt(
    fig, f"Plot of the relative convergence errors of {variable.output_name}."
)

# %% [markdown]
# ## Absolute values

# %% tags=["remove_input"]
fig = studies.convergence.plot_convergence(metrics, variable)
_show_with_alt(
    fig, f"Plot of the absolute convergence values of {variable.output_name}."
)
