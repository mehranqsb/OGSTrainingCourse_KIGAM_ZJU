# SPDX-FileCopyrightText: Copyright (c) OpenGeoSys Community (opengeosys.org)
# SPDX-License-Identifier: BSD-3-Clause

"""Plotting core utilitites."""

import warnings
from math import nextafter
from typing import Any

import numpy as np
import pyvista as pv
from matplotlib import cm
from matplotlib import pyplot as plt
from matplotlib import ticker as mticker
from matplotlib.patches import Rectangle as Rect
from matplotlib.tri import Triangulation
from PIL.Image import Image

from ogstools.plot import utils
from ogstools.plot.levels import combined_levels, level_boundaries
from ogstools.variables import Variable, Vector
from ogstools.variables.custom_colormaps import grey_cmap

from . import features
from .contourplots_pv import contourf_pv
from .levels import compute_levels, median_exponent
from .shared import setup
from .vectorplots import streamlines

# TODO: define default data_name for regions in setup


def get_ticklabels(ticks: np.ndarray) -> tuple[list[str], str | None]:
    """Get formatted tick labels and optional offset str.

    If all values in ticks are too close together offset notation is used.
    """
    if (
        median_exponent(ticks) >= 3 + median_exponent(ticks[-1] - ticks[0])
        and nextafter(ticks[0], np.inf) != ticks[-1]
    ):
        # use offset notation
        label_lens = np.asarray([len(str(tick)) for tick in ticks])
        offset = ticks[np.argmin(label_lens)]
    else:
        offset = 0
    if np.issubdtype(ticks.dtype, np.integer):
        return [str(tick) for tick in ticks], (
            None if offset == 0 else f"{offset:g}"
        )

    for precision in [1, 2, 3, 4]:
        fmt = (
            "f"
            if abs(median_exponent(ticks - offset)) <= 2
            or nextafter(ticks[0], np.inf) == ticks[-1]
            else "e"
        )
        tick_labels: list[str] = [
            f"{0.0 + tick:.{precision}{fmt}}" for tick in ticks - offset
        ]
        if len(tick_labels) == len(set(tick_labels)):
            break

    # pretty hacky but seems to do the job
    for idx, adj in [(0, 1), (-1, -2)]:
        if float(tick_labels[idx]) != float(tick_labels[adj]):
            continue
        for precision in range(12):
            new_ticklabel = f"{0.0 + ticks[idx] - offset:.{precision}{fmt}}"
            adj_ticklabel = f"{0.0 + ticks[adj] - offset:.{precision}{fmt}}"
            if float(new_ticklabel) != float(adj_ticklabel):
                tick_labels[idx] = new_ticklabel
                break
    if fmt != "e":
        tick_labels = [label.rstrip("0").rstrip(".") for label in tick_labels]
    return tick_labels, None if offset == 0 else f"{offset:g}"


def add_colorbars(
    fig: plt.Figure,
    ax: plt.Axes | list[plt.Axes],
    variable: Variable,
    levels: np.ndarray,
    **kwargs: Any,
) -> None:
    """Add a colorbar to the matplotlib figure."""
    if not kwargs.get("cbar", True):
        return
    ticks = levels
    if variable.categoric or (len(levels) == 2):
        bounds = level_boundaries(levels)
        ticks = bounds[:-1] + 0.5 * np.diff(bounds)

    continuous_cmap = kwargs.get("continuous_cmap", setup.continuous_cmap)

    with np.errstate(over="ignore"):
        cmap, norm = utils.get_cmap_norm(levels, variable, **kwargs)
        scalar_mappable = cm.ScalarMappable(norm=norm, cmap=cmap)
        cb_loc = kwargs.get("cb_loc", "right")
        cb_pad = kwargs.get("cb_pad", 0.15 if cb_loc == "left" else 0.05)
        cb = fig.colorbar(
            scalar_mappable,
            norm=norm,
            ax=ax,
            ticks=ticks,
            drawedges=not continuous_cmap,
            location=cb_loc,
            spacing="uniform",
            pad=cb_pad,
            extendrect=True,
        )
    if continuous_cmap and variable.bilinear_cmap:
        # fix stretched colorbar with Matplotlib's TwoSlopeNorm
        cb.ax.set_yscale("linear")
        cb.set_ticks(ticks)
    # Formatting the colorbar label and ticks

    tick_labels, offset = get_ticklabels(ticks)
    if continuous_cmap and len(ticks) > 2:
        half_delta = 0.5 * abs(np.median(np.diff(ticks)))
        if abs(ticks[1] - ticks[0]) < half_delta:
            tick_labels[1] = ""
        if abs(ticks[-1] - ticks[-2]) < half_delta:
            tick_labels[-2] = ""
    cb_label = variable.magnitude.get_label(setup.label_split)
    if offset is not None:
        if offset[0] == "-":
            cb_label += " + " + offset[1:]
        else:
            cb_label += " - " + offset
    if kwargs.get("log_scaled", setup.log_scaled):
        cb_label = f"log$_{{10}}$( {cb_label} )"
    labelsize = kwargs.get(
        "cb_labelsize", kwargs.get("fontsize", setup.fontsize)
    )
    cb.set_label(cb_label, size=labelsize)

    # special formatting for MaterialIDs
    if variable.data_name == "MaterialIDs" and setup.material_names is not None:
        tick_labels = [
            setup.material_names.get(mat_id, mat_id) for mat_id in levels
        ]
        cb.ax.set_ylabel("")
    elif variable.categoric:
        tick_labels = [str(level) for level in levels.astype(int)]
    cb.ax.tick_params(labelsize=labelsize, direction="out")
    cb.ax.set_yticklabels(tick_labels)

    # miscellaneous

    if variable.is_mask():
        cb.ax.add_patch(Rect((0, 0.5), 1, -1, lw=0, fc="none", hatch="/"))
    if setup.invert_colorbar:
        cb.ax.invert_yaxis()
    if variable.bilinear_cmap:
        cb.ax.axhline(y=0, color="w", lw=2 * setup.linewidth)


def subplot(
    mesh: pv.UnstructuredGrid,
    variable: Variable | str,
    ax: plt.Axes,
    levels: np.ndarray | None = None,
    **kwargs: Any,
) -> None:
    """Plot the variable field of a mesh on a matplotlib.axis.

    :param mesh: singular mesh
    :param variable: the field to be visualized on all meshes
    :param ax: matplotlib ax to use for plotting
    :param levels: value levels

    Matplotlib kwargs are also accepted.
    """

    variable = Variable.find(variable, mesh)
    if mesh.get_cell(0).dimension == 3:
        msg = "This method is for 2D meshes only, but found 3D elements."
        raise ValueError(msg)

    ax.axis("auto")

    if variable.mask_used(mesh):
        var_mask = variable.get_mask().replace(cmap=grey_cmap)
        subplot(
            mesh.threshold([0, 0], scalars=variable.mask),
            var_mask, ax, **kwargs,
        )  # fmt: skip
        mesh = mesh.ctp(pass_cell_data=True).threshold(
            value=[1, 1], scalars=variable.mask
        )

    x_id, y_id, projection, _ = utils.get_projection(mesh)
    if "xlim" in kwargs or "ylim" in kwargs:
        limits = np.asarray(utils.xy_limits(mesh, **kwargs))
        pts = mesh.points
        in_x = (pts[:, x_id] >= limits[0]) & (pts[:, x_id] <= limits[1])
        in_y = (pts[:, y_id] >= limits[2]) & (pts[:, y_id] <= limits[3])
        point_ids = np.argwhere(in_x & in_y)

        # explicitly checking corner cells, as they might be missing if only
        # checking for the points being inside the limits.
        lim_ids_pairs = [[0, 2], [1, 2], [1, 3], [0, 3]]
        z = np.median(mesh.points[:, projection])
        corner_pts = np.hstack([limits[lim_ids_pairs], [[z]] * 4])
        ids_ = mesh.find_containing_cell(corner_pts)
        corner_cells = [ids_] if isinstance(ids_, int) else ids_
        for edge_cell in [idx for idx in corner_cells if idx != -1]:
            new_ids = mesh.get_cell(edge_cell).point_ids
            point_ids = np.append(
                point_ids, [new_ids] if isinstance(new_ids, int) else new_ids
            )

        mesh = mesh.extract_points(point_ids.astype(int))
        if mesh.n_points == 0:
            msg = "Limits where chosen such, that no points remain. "
            raise ValueError(msg)

    surf_tri = mesh.triangulate().extract_surface(algorithm="dataset_surface")
    # Get rid of 1D elements in the mesh
    surf_tri = surf_tri.extract_cells_by_type(pv.CellType.TRIANGLE)

    # faces contains a padding indicating number of points per face which gets
    # removed with this reshaping and slicing to get the array of tri's
    x, y = surf_tri.points.T[[x_id, y_id]]
    tri = surf_tri.faces.reshape((-1, 4))[:, 1:]
    values = variable.magnitude.transform(surf_tri)
    # Passing the data and not the mesh here purposely to ensure correct shape
    # of mask. Otherwise transform() might remove additional triangulated cells
    # due to those being part of the usual mask e.g. "pressure_active".
    nan_mask = np.isnan(
        surf_tri.ptc().cell_data.get(
            variable.data_name, np.zeros(surf_tri.n_cells)
        )
    )
    # Getting rid of extra dimension for vectors and matrices
    if len(nan_mask.shape) == 2:
        nan_mask = np.sum(nan_mask, axis=-1)
    if kwargs.get("log_scaled", setup.log_scaled) and not variable.is_mask():
        if np.any(values <= 0.0):
            nan_mask[np.any(values[tri] <= 0.0, axis=-1)] = True
        values = np.log10(
            values,
            where=values > 0.0,
            out=np.ones_like(values) * kwargs.get("vmin", np.nan),
        )
    vmin, vmax = np.nanmin(values), np.nanmax(values)

    if levels is None:
        num_levels = min(
            kwargs.get("num_levels", setup.num_levels), len(np.unique(values))
        )
        levels = compute_levels(vmin, vmax, num_levels)
    cmap, norm = utils.get_cmap_norm(levels, variable, **kwargs)

    conti_cmap = kwargs.get("continuous_cmap", setup.continuous_cmap)
    alpha = kwargs.get("alpha", 1)
    # norm.__call__ overflows if vals are all equal
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        triangulation = Triangulation(x, y, tri, mask=nan_mask)
        if variable.data_name in surf_tri.point_data:
            tri_levels = 255 if conti_cmap else kwargs.get("levels", levels)
            ax.tricontourf(
                triangulation, values, levels=tri_levels, alpha=alpha,
                cmap=cmap, norm=norm, extend="both"
            )  # fmt: skip
            if variable.bilinear_cmap:
                ax.tricontour(triangulation, values, levels=[0], colors="w")
        else:
            ax.tripcolor(
                triangulation, facecolors=values,
                cmap=cmap, norm=norm, alpha=alpha,
            )  # fmt: skip
            if variable.is_mask():
                mask_triangulation = Triangulation(
                    x, y, tri, mask=(values == 1)
                )
                ax.tripcolor(
                    mask_triangulation, facecolors=values,
                    cmap=cmap, norm=norm, hatch="/"
                )  # fmt: skip

    show_edges = setup.show_element_edges
    if isinstance(setup.show_element_edges, str):
        show_edges = setup.show_element_edges == variable.data_name
    show_edges = kwargs.get("show_edges", show_edges)
    if show_edges:
        features.element_edges(ax, mesh, projection)
    show_region_bounds = kwargs.get(
        "show_region_bounds", setup.show_region_bounds
    )
    if show_region_bounds:
        features.layer_boundaries(ax, mesh, projection)

    if isinstance(variable, Vector):
        streamlines(
            surf_tri,
            ax,
            variable,
            projection,
            kwargs.get("arrowsize", setup.arrowsize),
            kwargs.get("density", 1.5),
            kwargs.get("streamlinewidth", 2.5),
        )

    ax.margins(0, 0)  # otherwise it shrinks the plot content
    show_max = kwargs.get("show_max", False) and not variable.is_mask()
    show_min = kwargs.get("show_min", False) and not variable.is_mask()
    fontsize = kwargs.get("fontsize", setup.fontsize)

    # TODO: refactor to provide a function to return pos and val of min / max
    for show, func, level_index in zip(
        [show_min, show_max], [np.argmin, np.argmax], [0, -1], strict=True
    ):
        if not show:
            continue
        index = np.unravel_index(func(values), values.shape)[0]
        x_pos, y_pos = (x[index], y[index])

        color = utils.contrast_color(cmap(norm(func(values))))
        ax.plot(
            x_pos, y_pos, color=color, marker="x", clip_on=False,
            markersize=fontsize*0.625, markeredgewidth=3
        )  # fmt: skip
        pad_x = not (show_min and show_max)  # prevent overlap
        text_xy = utils.padded(ax, x_pos, y_pos, pad_x)
        text = f"{levels[level_index]:.3g}"
        ha, va = ("center", "center")
        ax.text(*text_xy, s=text, ha=ha, va=va, fontsize=fontsize, color=color)


# TODO: fixed_figure_size -> ax aspect automatic


def _fig_init(
    rows: int, cols: int, aspect: float = 1.0, **kwargs: Any
) -> tuple[plt.Figure, plt.Axes | np.ndarray]:
    nx_cb = 1 if setup.combined_colorbar else cols
    default_size = 8
    cb_width = 3
    y_label_width = 2
    x_label_height = 1
    figsize = np.asarray(
        [
            default_size * cols * aspect + cb_width * nx_cb + y_label_width,
            default_size * rows + x_label_height,
        ]
    )
    # TODO: maybe use height and width_ratios argument?
    fig, ax = plt.subplots(
        rows,
        cols,
        dpi=kwargs.get("dpi", setup.dpi),
        figsize=kwargs.get("figsize", figsize),
        layout=kwargs.get("layout", setup.layout),
        sharex=True,
        sharey=True,
    )
    fig.patch.set_alpha(1)
    return fig, ax


# TODO: Have a look at fig and ax logic and make it more readable


def _take_axes(
    fig: plt.Figure | None, axes: plt.Axes | None, shape: tuple[int, ...]
) -> np.ndarray:
    match fig, axes:
        case None, None:
            msg = "Neither figure nor axes was provided."
            raise TypeError(msg)
        case fig, None:
            msg = (
                "This is not a good practice. Consider providing both fig "
                "and axes instead. This option may lead to unexpected "
                "behaviour and may be removed in the future."
            )
            warnings.warn(msg, Warning, stacklevel=4)
            assert isinstance(fig, plt.Figure)
            return np.reshape(np.asarray(fig.axes), shape)
        case None, axes:
            if shape != (1, 1):
                msg = (
                    "You provided only one axes but multiple meshes."
                    "Provide one mesh per axes or provide a figure."
                )
                raise ValueError(msg)
            return np.reshape(np.array(axes), (1, 1))
    return np.reshape(np.asarray(axes), shape)


def label_sec_ax(
    mesh: pv.UnstructuredGrid, ax: plt.Axes, x2_var: Variable, fontsize: float
) -> None:
    _, _, projection, mean_normal = utils.get_projection(mesh)
    if abs(max(mean_normal) - 1) <= 1e-2:
        return
    sec_id = np.argmax(np.delete(mean_normal, projection))
    sec_labels = []
    for tick in ax.get_xticks():
        origin = np.array(mesh.center)
        origin[sec_id] = min(
            max(tick, mesh.bounds[2 * sec_id] + 1e-6),
            mesh.bounds[2 * sec_id + 1] - 1e-6,
        )
        sec_mesh = mesh.slice("xyz"[sec_id], origin=origin)
        if sec_mesh.n_cells:
            sec_labels += [f"{sec_mesh.bounds[2 * projection]:.1f}"]
        else:
            sec_labels += [""]
    if not all(label == sec_labels[0] for label in sec_labels):
        secax = ax.secondary_xaxis("top")
        secax.xaxis.set_major_locator(
            mticker.FixedLocator(list(ax.get_xticks()))
        )
        secax.set_xticklabels(sec_labels)
        secax.set_xlabel(x2_var.get_label())
        utils.update_font_sizes(secax, fontsize)
        # secax.tick_params(top=True)


def draw_plot(
    meshes: list[pv.UnstructuredGrid] | np.ndarray | pv.UnstructuredGrid,
    variable: Variable,
    fig: plt.Figure | None = None,
    axes: plt.Axes | None = None,
    **kwargs: Any,
) -> plt.Figure | None:
    """
    Plot the variable field of meshes on an existing figure or axis.

    :param meshes: singular mesh or 2D numpy array of meshes
    :param variable: the field to be visualized on all meshes
    :param fig: matplotlib figure to use for plotting
    :param axes: matplotlib axes to use for plotting
    """
    shape = utils.get_rows_cols(meshes)
    np_meshes = np.reshape(meshes, shape)
    np_axs = _take_axes(fig, axes, shape)

    # One mesh is sufficient, it should be the same for all of them
    mesh_0 = np_meshes.flat[0]
    x_id, y_id, projection, _ = utils.get_projection(mesh_0)
    x_var, y_var, x2_var = (
        Variable.find("xyz"[idx], mesh_0) for idx in (x_id, y_id, projection)
    )

    if setup.combined_colorbar:
        _levels = combined_levels(np_meshes, variable, **kwargs)
    for i, j in [(r0, r1) for r0 in range(shape[0]) for r1 in range(shape[1])]:
        # np_axs[i, j].tick_params(
        #     direction="out", bottom=True, left=True, right=False, top=False
        # )
        if "levels" in kwargs:
            _levels = np.asarray(kwargs.pop("levels"))
        elif not setup.combined_colorbar:
            _levels = combined_levels(np_meshes[i, j, None], variable, **kwargs)
        subplot(np_meshes[i, j], variable, np_axs[i, j], _levels, **kwargs)
        label_sec_ax(
            np_meshes[i, j], np_axs[i, j], x2_var,
            kwargs.get("fontsize", setup.fontsize)
        )  # fmt: skip
        if fig is None or setup.combined_colorbar:
            continue
        add_colorbars(fig, np_axs[i, j], variable, _levels, **kwargs)

    utils.label_spatial_axes(fig, np_axs, x_var, y_var)
    # make extra space for the upper limit of the colorbar
    if setup.layout == "tight" and fig is not None:
        fig.tight_layout(pad=1.4)
    if fig is not None and setup.combined_colorbar:
        cb_axs = np.ravel(np.asarray(fig.axes)).tolist()
        add_colorbars(fig, cb_axs, variable, _levels, **kwargs)
    return fig


def _set_aspect(ax: plt.Axes, aspect: float, **kwargs: Any) -> None:
    if "xlim" in kwargs:
        ax.set_xlim(kwargs["xlim"])
    if "ylim" in kwargs:
        ax.set_ylim(kwargs["ylim"])
    ax.set_aspect(1.0 / aspect)


def contourf(
    meshes: list[pv.UnstructuredGrid] | np.ndarray | pv.UnstructuredGrid,
    variable: Variable | str,
    fig: plt.Figure | None = None,
    ax: plt.Axes | None = None,
    interactive: bool | None = None,
    **kwargs: Any,
) -> plt.Figure | pv.Plotter | Image | list[pv.Plotter] | list[Image] | None:
    """
    Plot the variable field of meshes with default settings.

    The resulting figure adheres to the configurations in plot.setup.
    For 2D meshes matplotlib backend is used, for 3D pyvista backend.

    :param meshes:      Singular mesh of 2D numpy array of meshes
    :param variable:    The field to be visualized on all meshes
    :param fig:         matplotlib figure to use for plotting
    :param ax:          matplotlib axis to use for plotting
    :param interactive: By default: 2D mesh -> matplotlib, 3D mesh -> pyvista,
                        if True: always use interactive pyvista plot
                        if False and 3D mesh: -> pyvista static Image

    Keyword Arguments:
        - arrowsize           scaling factor for arrowsize
        - cbar:               If True (default), draw a colorbar
        - cb_labelsize:       colorbar labelsize
        - cb_loc:             colorbar location ('left' or 'right')
        - cb_pad:             colorbar padding
        - cmap:               colormap
        - dpi:                resolution
        - figsize:            figure size
        - fontsize            size for labels and captions
        - levels:             user defined levels
        - log_scaled:         logarithmic scaling
        - min_ax_aspect:         minimum axes aspect ratio
        - max_ax_aspect:         maximum axes aspect ratio
        - show_edges:         show element edges
        - show_max:           mark the location of the maximum value
        - show_min:           mark the location of the minimum value
        - show_region_bounds: show the edges of the different regions
        - vmin:               minimum value
        - vmax:               maximum value
        - xlim:               limits as [min, max], use None for auto limit
        - ylim:               limits as [min, max], use None for auto limit
        - alpha:              opaqueness (1: opaque, 0: transparent)
    """

    shape = utils.get_rows_cols(meshes)
    _meshes = np.reshape(meshes, shape).ravel()
    max_dim = max([mesh.GetMaxSpatialDimension() for mesh in _meshes])
    if interactive or max_dim == 3:
        plotters = [contourf_pv(mesh, variable, **kwargs) for mesh in _meshes]
        if interactive is False:
            for pl in plotters:
                pl.show(jupyter_backend="static", interactive=False)
            return None
        return plotters[0] if len(plotters) == 1 else plotters

    variable = Variable.find(variable, _meshes[0])
    data_aspects = np.asarray(
        [utils.get_data_aspect(mesh, **kwargs) for mesh in _meshes]
    )
    min_ax_aspect = kwargs.get("min_ax_aspect", setup.min_ax_aspect)
    max_ax_aspect = kwargs.get("max_ax_aspect", setup.max_ax_aspect)
    if min_ax_aspect is None and max_ax_aspect is None:
        fig_aspect = np.mean(data_aspects)
    else:
        fig_aspect = np.mean(
            np.clip(data_aspects, min_ax_aspect, max_ax_aspect)
        )
    ax_aspects = fig_aspect / data_aspects
    n_axs = shape[0] * shape[1]
    if fig is None and ax is None:
        fig, ax = _fig_init(shape[0], shape[1], fig_aspect, **kwargs)
        optional_return_figure = fig
    else:
        optional_return_figure = None

    fig = draw_plot(meshes, variable, fig=fig, axes=ax, **kwargs)

    if ax is not None and isinstance(ax, plt.Axes):
        _set_aspect(ax, ax_aspects[0], **kwargs)
        utils.update_font_sizes(
            ax, fontsize=kwargs.get("fontsize", setup.fontsize)
        )
    elif fig is not None:
        _ax: plt.Axes
        for _ax, aspect in zip(fig.axes[:n_axs], ax_aspects, strict=True):
            _set_aspect(_ax, aspect, **kwargs)

    if optional_return_figure is None:
        return None
    assert fig is not None
    utils.update_font_sizes(
        fig.axes, fontsize=kwargs.get("fontsize", setup.fontsize)
    )
    return fig
