import importlib
import logging
import os
import sys

vtk_module_name = os.environ.get("VTK_MODULE_NAME", "vtkmodules")
sys.modules["vtk_module"] = importlib.import_module(vtk_module_name)

from vtk_module.vtkCommonCore import vtkCommand  # noqa: E402

from .cache import remove_from_cache  # noqa: E402
from .registry import SERIALIZERS, class_name  # noqa: E402
from .widgets import handle_widget  # noqa: E402

__all__ = ["serialize", "serialize_widget"]

logger = logging.getLogger(__name__)

# Keep track of which warnings have been printed
NO_SERIALIZER_FOR_INSTANCE = {}
DELETE_CALLBACKS = []


def serialize(parent, instance, instance_id, context, depth):
    instance_type = class_name(instance)
    serializer = SERIALIZERS.get(instance_type, None)
    if instance_id not in DELETE_CALLBACKS:
        instance.AddObserver(
            vtkCommand.DeleteEvent, lambda *_a, **_k: remove(instance_id)
        )
        DELETE_CALLBACKS.append(instance_id)

    if serializer:
        return serializer(parent, instance, instance_id, context, depth)

    if instance_type not in NO_SERIALIZER_FOR_INSTANCE:
        # Only print the warning once for each type of serializer
        logger.warning("!!!No serializer for %s with id %s", instance_type, instance_id)
        NO_SERIALIZER_FOR_INSTANCE[instance_type] = instance_id

    return None


def remove(instance_id):
    remove_from_cache(instance_id)
    DELETE_CALLBACKS.remove(instance_id)


def serialize_widget(dict_out, widget):
    handle_widget(dict_out, widget)
