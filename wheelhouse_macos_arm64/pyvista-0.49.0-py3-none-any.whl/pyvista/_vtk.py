"""Lazy-loaded imports from VTK.

These are the modules within VTK that must be loaded across pyvista's
core and plotting API. The modules are lazily loaded, and are only
imported on first access. We import from ``vtkmodules`` instead of
``vtk`` to selectively import modules and not the entire library.

"""

from __future__ import annotations

import importlib
import importlib.util
import os
from typing import TYPE_CHECKING


def _resolve_vtk_root() -> str:
    """Return the root package PyVista resolves VTK imports against.

    ``PYVISTA_VTK_BACKEND`` wins if set (``vtk``/``vtkmodules`` for stock, a name
    like ``cvista`` for the fork); else auto-select ``cvista`` if installed; else
    stock ``vtkmodules``. Resolved at import, so set the variable before importing
    :mod:`pyvista`.
    """
    backend = os.environ.get('PYVISTA_VTK_BACKEND')
    if backend:
        # `vtk` is what vtk_backend() reports for stock; map it to the real root
        # (the `vtk` shim is eager and does not re-export every name).
        return 'vtkmodules' if backend == 'vtk' else backend
    if importlib.util.find_spec('cvista') is not None:
        return 'cvista'
    return 'vtkmodules'


# Root package VTK imports resolve against. Only used for the few *module* imports
# made for their side effects (factory registration); classes go through __getattr__.
_VTK_ROOT = _resolve_vtk_root()


def _resolve_root_is_flat(root: str) -> bool:
    """Return whether ``root`` exposes VTK classes directly off its package root.

    A flat backend (for example, cvista >=9.6.2.4) resolves public names lazily off the
    root, so PyVista looks classes up by NAME and stays agnostic to module layout.
    Probed rather than inferred, since a custom build may be laid out like stock VTK.
    """
    if root == 'vtkmodules':
        return False
    try:
        module = importlib.import_module(root)
    except ImportError as e:
        msg = (
            f'The VTK backend {root!r} is not importable. It is selected by '
            f'PYVISTA_VTK_BACKEND or by being installed alongside PyVista.'
        )
        raise ImportError(msg) from e
    # vtkPolyData exists in every supported build, so its presence marks a flat root.
    return hasattr(module, 'vtkPolyData')


_VTK_ROOT_IS_FLAT = _resolve_root_is_flat(_VTK_ROOT)


if TYPE_CHECKING:
    from collections.abc import Callable
    from typing import Any

    # Type checkers cannot resolve the dynamic lazy vtk imports, so we import everything
    # here as needed to ensure they can "see" the imported classes
    from vtk import *  # noqa: TID251
    from vtkmodules.numpy_interface.dataset_adapter import *  # noqa: TID251
    from vtkmodules.util.vtkAlgorithm import *  # noqa: TID251

# Canonical mapping: vtkmodule -> classes
# Modules imported for pyvista's core API
_CORE_MODULES: dict[str, tuple[str, ...]] = {
    'numpy_interface.dataset_adapter': (
        'VTKArray',
        'VTKObjectWrapper',
        'numpyTovtkDataArray',
    ),
    'numpy_interface.vtk_aos_array': ('VTKAOSArray',),
    'numpy_interface.vtk_implicit_array': ('VTKImplicitArray',),
    'util.numpy_support': (
        'get_vtk_array_type',
        'numpy_to_vtk',
        'numpy_to_vtkIdTypeArray',
        'vtk_to_numpy',
    ),
    'util.pickle_support': ('serialize_VTK_data_object',),
    'util.vtkAlgorithm': ('VTKPythonAlgorithmBase',),
    'vtkCommonComputationalGeometry': (
        'vtkKochanekSpline',
        'vtkParametricBohemianDome',
        'vtkParametricBour',
        'vtkParametricBoy',
        'vtkParametricCatalanMinimal',
        'vtkParametricConicSpiral',
        'vtkParametricCrossCap',
        'vtkParametricDini',
        'vtkParametricEllipsoid',
        'vtkParametricEnneper',
        'vtkParametricFigure8Klein',
        'vtkParametricFunction',
        'vtkParametricHenneberg',
        'vtkParametricKlein',
        'vtkParametricKuen',
        'vtkParametricMobius',
        'vtkParametricPluckerConoid',
        'vtkParametricPseudosphere',
        'vtkParametricRandomHills',
        'vtkParametricRoman',
        'vtkParametricSpline',
        'vtkParametricSuperEllipsoid',
        'vtkParametricSuperToroid',
        'vtkParametricTorus',
    ),
    'vtkCommonCore': (
        'VTK_ARIAL',
        'VTK_COURIER',
        'VTK_DOUBLE_MAX',
        'VTK_DOUBLE_MIN',
        'VTK_FONT_FILE',
        'VTK_TIMES',
        'VTK_UNSIGNED_CHAR',
        'buffer_shared',
        'mutable',
        'reference',
        'vtkAbstractArray',
        'vtkBitArray',
        'vtkCharArray',
        'vtkCommand',
        'vtkDataArray',
        'vtkDoubleArray',
        'vtkFileOutputWindow',
        'vtkFloatArray',
        'vtkIdList',
        'vtkIdTypeArray',
        'vtkInformation',
        'vtkLogger',
        'vtkLookupTable',
        'vtkMath',
        'vtkObjectBase',
        'vtkOutputWindow',
        'vtkPoints',
        'vtkSMPTools',
        'vtkSignedCharArray',
        'vtkStringArray',
        'vtkStringOutputWindow',
        'vtkTypeInt32Array',
        'vtkTypeInt64Array',
        'vtkTypeUInt32Array',
        'vtkUnsignedCharArray',
        'vtkVersion',
        'vtkWeakReference',
    ),
    'vtkCommonDataModel': (
        'VTK_BEZIER_CURVE',
        'VTK_BEZIER_HEXAHEDRON',
        'VTK_BEZIER_PYRAMID',
        'VTK_BEZIER_QUADRILATERAL',
        'VTK_BEZIER_TETRAHEDRON',
        'VTK_BEZIER_TRIANGLE',
        'VTK_BEZIER_WEDGE',
        'VTK_BIQUADRATIC_QUAD',
        'VTK_BIQUADRATIC_QUADRATIC_HEXAHEDRON',
        'VTK_BIQUADRATIC_QUADRATIC_WEDGE',
        'VTK_BIQUADRATIC_TRIANGLE',
        'VTK_CONVEX_POINT_SET',
        'VTK_CUBIC_LINE',
        'VTK_EMPTY_CELL',
        'VTK_HEXAGONAL_PRISM',
        'VTK_HEXAHEDRON',
        'VTK_HIGHER_ORDER_EDGE',
        'VTK_HIGHER_ORDER_HEXAHEDRON',
        'VTK_HIGHER_ORDER_POLYGON',
        'VTK_HIGHER_ORDER_PYRAMID',
        'VTK_HIGHER_ORDER_QUAD',
        'VTK_HIGHER_ORDER_TETRAHEDRON',
        'VTK_HIGHER_ORDER_TRIANGLE',
        'VTK_HIGHER_ORDER_WEDGE',
        'VTK_LAGRANGE_CURVE',
        'VTK_LAGRANGE_HEXAHEDRON',
        'VTK_LAGRANGE_PYRAMID',
        'VTK_LAGRANGE_QUADRILATERAL',
        'VTK_LAGRANGE_TETRAHEDRON',
        'VTK_LAGRANGE_TRIANGLE',
        'VTK_LAGRANGE_WEDGE',
        'VTK_LINE',
        'VTK_PARAMETRIC_CURVE',
        'VTK_PARAMETRIC_HEX_REGION',
        'VTK_PARAMETRIC_QUAD_SURFACE',
        'VTK_PARAMETRIC_SURFACE',
        'VTK_PARAMETRIC_TETRA_REGION',
        'VTK_PARAMETRIC_TRI_SURFACE',
        'VTK_PENTAGONAL_PRISM',
        'VTK_PIXEL',
        'VTK_POLYGON',
        'VTK_POLYHEDRON',
        'VTK_POLY_LINE',
        'VTK_POLY_VERTEX',
        'VTK_PYRAMID',
        'VTK_QUAD',
        'VTK_QUADRATIC_EDGE',
        'VTK_QUADRATIC_HEXAHEDRON',
        'VTK_QUADRATIC_LINEAR_QUAD',
        'VTK_QUADRATIC_LINEAR_WEDGE',
        'VTK_QUADRATIC_POLYGON',
        'VTK_QUADRATIC_PYRAMID',
        'VTK_QUADRATIC_QUAD',
        'VTK_QUADRATIC_TETRA',
        'VTK_QUADRATIC_TRIANGLE',
        'VTK_QUADRATIC_WEDGE',
        'VTK_TETRA',
        'VTK_TRIANGLE',
        'VTK_TRIANGLE_STRIP',
        'VTK_TRIQUADRATIC_HEXAHEDRON',
        'VTK_TRIQUADRATIC_PYRAMID',
        'VTK_VERTEX',
        'VTK_VOXEL',
        'VTK_WEDGE',
        'vtkAbstractCellLocator',
        'vtkAbstractPointLocator',
        'vtkBezierCurve',
        'vtkBezierHexahedron',
        'vtkBezierQuadrilateral',
        'vtkBezierTetra',
        'vtkBezierTriangle',
        'vtkBezierWedge',
        'vtkBiQuadraticQuad',
        'vtkBiQuadraticQuadraticHexahedron',
        'vtkBiQuadraticQuadraticWedge',
        'vtkBiQuadraticTriangle',
        'vtkCell',
        'vtkCellArray',
        'vtkCellLocator',
        'vtkCellStatus',
        'vtkCellTreeLocator',
        'vtkCellTypes',
        'vtkColor3ub',
        'vtkCompositeDataSet',
        'vtkConvexPointSet',
        'vtkCubicLine',
        'vtkDataObject',
        'vtkDataSet',
        'vtkDataSetAttributes',
        'vtkEmptyCell',
        'vtkExplicitStructuredGrid',
        'vtkFieldData',
        'vtkGenericCell',
        'vtkHexagonalPrism',
        'vtkHexahedron',
        'vtkImageData',
        'vtkImplicitBoolean',
        'vtkImplicitFunction',
        'vtkIterativeClosestPointTransform',
        'vtkLagrangeCurve',
        'vtkLagrangeHexahedron',
        'vtkLagrangeQuadrilateral',
        'vtkLagrangeTetra',
        'vtkLagrangeTriangle',
        'vtkLagrangeWedge',
        'vtkLine',
        'vtkLocator',
        'vtkMultiBlockDataSet',
        'vtkNonMergingPointLocator',
        'vtkPartitionedDataSet',
        'vtkPentagonalPrism',
        'vtkPerlinNoise',
        'vtkPiecewiseFunction',
        'vtkPixel',
        'vtkPlane',
        'vtkPlaneCollection',
        'vtkPlanes',
        'vtkPointLocator',
        'vtkPointSet',
        'vtkPolyData',
        'vtkPolyLine',
        'vtkPolyPlane',
        'vtkPolyVertex',
        'vtkPolygon',
        'vtkPolyhedron',
        'vtkPyramid',
        'vtkQuad',
        'vtkQuadraticEdge',
        'vtkQuadraticHexahedron',
        'vtkQuadraticLinearQuad',
        'vtkQuadraticLinearWedge',
        'vtkQuadraticPolygon',
        'vtkQuadraticPyramid',
        'vtkQuadraticQuad',
        'vtkQuadraticTetra',
        'vtkQuadraticTriangle',
        'vtkQuadraticWedge',
        'vtkRectf',
        'vtkRectilinearGrid',
        'vtkSelection',
        'vtkSelectionNode',
        'vtkStaticCellLocator',
        'vtkStaticPointLocator',
        'vtkStructuredGrid',
        'vtkStructuredPoints',
        'vtkTable',
        'vtkTetra',
        'vtkTriQuadraticHexahedron',
        'vtkTriQuadraticPyramid',
        'vtkTriangle',
        'vtkTriangleStrip',
        'vtkUnstructuredGrid',
        'vtkVertex',
        'vtkVoxel',
        'vtkWedge',
    ),
    'vtkCommonExecutionModel': (
        'vtkAlgorithm',
        'vtkAlgorithmOutput',
        'vtkCompositeDataPipeline',
        'vtkImageToStructuredGrid',
        'vtkStreamingDemandDrivenPipeline',
    ),
    'vtkCommonMath': (
        'vtkMatrix3x3',
        'vtkMatrix4x4',
    ),
    'vtkCommonTransforms': ('vtkTransform',),
    'vtkDomainsChemistry': ('vtkProteinRibbonFilter',),
    'vtkFiltersCore': (
        'VTK_BEST_FITTING_PLANE',
        'vtkAppendArcLength',
        'vtkAppendFilter',
        'vtkAppendPolyData',
        'vtkCellCenters',
        'vtkCellDataToPointData',
        'vtkCenterOfMass',
        'vtkCleanPolyData',
        'vtkClipPolyData',
        'vtkConnectivityFilter',
        'vtkContourFilter',
        'vtkConvertToMultiBlockDataSet',
        'vtkConvexHull',
        'vtkCutter',
        'vtkDecimatePolylineFilter',
        'vtkDecimatePro',
        'vtkDelaunay2D',
        'vtkDelaunay3D',
        'vtkElevationFilter',
        'vtkExplicitStructuredGridToUnstructuredGrid',
        'vtkExtractCells',
        'vtkExtractEdges',
        'vtkFeatureEdges',
        'vtkFlyingEdges3D',
        'vtkGlyph3D',
        'vtkImageAppend',
        'vtkImplicitPolyDataDistance',
        'vtkMarchingCubes',
        'vtkMassProperties',
        'vtkMergeFilter',
        'vtkOrientPolyData',
        'vtkPackLabels',
        'vtkPointDataToCellData',
        'vtkPolyDataNormals',
        'vtkQuadricDecimation',
        'vtkResampleWithDataSet',
        'vtkReverseSense',
        'vtkSmoothPolyDataFilter',
        'vtkStaticCleanUnstructuredGrid',
        'vtkStripper',
        'vtkSurfaceNets3D',
        'vtkThreshold',
        'vtkTriangleFilter',
        'vtkTubeFilter',
        'vtkUnstructuredGridToExplicitStructuredGrid',
        'vtkWindowedSincPolyDataFilter',
    ),
    'vtkFiltersExtraction': (
        'vtkExtractCellsByType',
        'vtkExtractExodusGlobalTemporalVariables',
        'vtkExtractGeometry',
        'vtkExtractGrid',
        'vtkExtractSelection',
    ),
    'vtkFiltersFlowPaths': (
        'vtkEvenlySpacedStreamlines2D',
        'vtkStreamTracer',
    ),
    'vtkFiltersGeneral': (
        'vtkAxes',
        'vtkBooleanOperationPolyDataFilter',
        'vtkBoxClipDataSet',
        'vtkCellValidator',
        'vtkClipClosedSurface',
        'vtkContourTriangulator',
        'vtkCursor3D',
        'vtkCurvatures',
        'vtkDataSetTriangleFilter',
        'vtkGradientFilter',
        'vtkIntersectionPolyDataFilter',
        'vtkOBBTree',
        'vtkRectilinearGridToPointSet',
        'vtkRectilinearGridToTetrahedra',
        'vtkShrinkFilter',
        'vtkTableBasedClipDataSet',
        'vtkTableToPolyData',
        'vtkTessellatorFilter',
        'vtkTransformFilter',
        'vtkWarpScalar',
        'vtkWarpVector',
    ),
    'vtkFiltersGeometry': (
        'vtkCompositeDataGeometryFilter',
        'vtkDataSetSurfaceFilter',
        'vtkGeometryFilter',
        'vtkStructuredGridGeometryFilter',
    ),
    'vtkFiltersHybrid': (
        'vtkFacetReader',
        'vtkPolyDataSilhouette',
    ),
    'vtkFiltersModeling': (
        'vtkAdaptiveSubdivisionFilter',
        'vtkBandedPolyDataContourFilter',
        'vtkButterflySubdivisionFilter',
        'vtkCollisionDetectionFilter',
        'vtkDijkstraGraphGeodesicPath',
        'vtkFillHolesFilter',
        'vtkLinearExtrusionFilter',
        'vtkLinearSubdivisionFilter',
        'vtkLoopSubdivisionFilter',
        'vtkOutlineFilter',
        'vtkRibbonFilter',
        'vtkRotationalExtrusionFilter',
        'vtkRuledSurfaceFilter',
        'vtkSelectEnclosedPoints',
        'vtkSubdivideTetra',
        'vtkTrimmedExtrusionFilter',
    ),
    'vtkFiltersParallel': ('vtkIntegrateAttributes',),
    'vtkFiltersParallelDIY2': ('vtkRedistributeDataSetFilter',),
    'vtkFiltersPoints': (
        'vtkConvertToPointCloud',
        'vtkGaussianKernel',
        'vtkPointInterpolator',
    ),
    'vtkFiltersSources': (
        'vtkArcSource',
        'vtkArrowSource',
        'vtkCapsuleSource',  # Deprecated 9.3.0
        'vtkCellTypeSource',
        'vtkConeSource',
        'vtkCubeSource',
        'vtkCylinderSource',
        'vtkDiskSource',
        'vtkFrustumSource',
        'vtkLineSource',
        'vtkOutlineCornerFilter',
        'vtkOutlineCornerSource',
        'vtkParametricFunctionSource',
        'vtkPlaneSource',
        'vtkPlatonicSolidSource',
        'vtkPointSource',
        'vtkRegularPolygonSource',
        'vtkSphereSource',
        'vtkSuperquadricSource',
        'vtkTessellatedBoxSource',
    ),
    'vtkFiltersStatistics': (
        'vtkComputeQuartiles',
        'vtkLengthDistribution',
    ),
    'vtkFiltersTexture': (
        'vtkTextureMapToPlane',
        'vtkTextureMapToSphere',
    ),
    'vtkFiltersVerdict': (
        'vtkBoundaryMeshQuality',
        'vtkCellQuality',
        'vtkCellSizeFilter',
        'vtkMeshQuality',
    ),
    'vtkIOCGNSReader': ('vtkCGNSReader',),
    'vtkIOChemistry': (
        'vtkGaussianCubeReader',
        'vtkPDBReader',
    ),
    'vtkIOEnSight': ('vtkGenericEnSightReader',),
    'vtkIOExodus': ('vtkExodusIIReader',),
    'vtkIOExport': (
        'vtkGLTFExporter',
        'vtkOBJExporter',
        'vtkVRMLExporter',
    ),
    'vtkIOExportGL2PS': ('vtkGL2PSExporter',),
    'vtkIOFLUENTCFF': ('vtkFLUENTCFFReader',),
    'vtkIOGeometry': (
        'vtkAVSucdReader',
        'vtkBYUReader',
        'vtkFLUENTReader',
        'vtkGAMBITReader',
        'vtkGLTFReader',
        'vtkHoudiniPolyDataWriter',
        'vtkIVWriter',
        'vtkMCubesReader',
        'vtkMFIXReader',
        'vtkOBJReader',
        'vtkOBJWriter',
        'vtkOpenFOAMReader',
        'vtkPTSReader',
        'vtkParticleReader',
        'vtkProStarReader',
        'vtkSTLReader',
        'vtkSTLWriter',
        'vtkTecplotReader',
    ),
    'vtkIOHDF': (
        'vtkHDFReader',
        'vtkHDFWriter',
    ),
    'vtkIOImage': (
        'vtkBMPReader',
        'vtkBMPWriter',
        'vtkDEMReader',
        'vtkDICOMImageReader',
        'vtkGESignaReader',
        'vtkHDRReader',
        'vtkJPEGReader',
        'vtkJPEGWriter',
        'vtkMetaImageReader',
        'vtkNIFTIImageReader',
        'vtkNIFTIImageWriter',
        'vtkNrrdReader',
        'vtkPNGReader',
        'vtkPNGWriter',
        'vtkPNMReader',
        'vtkPNMWriter',
        'vtkSLCReader',
        'vtkTIFFReader',
        'vtkTIFFWriter',
    ),
    'vtkIOImport': (
        'vtk3DSImporter',
        'vtkGLTFImporter',
        'vtkOBJImporter',
        'vtkVRMLImporter',
    ),
    'vtkIOInfovis': ('vtkDelimitedTextReader',),
    'vtkIOLegacy': (
        'vtkDataSetReader',
        'vtkDataSetWriter',
        'vtkDataWriter',
        'vtkPolyDataWriter',
        'vtkRectilinearGridWriter',
        'vtkSimplePointsWriter',
        'vtkStructuredGridWriter',
        'vtkUnstructuredGridWriter',
    ),
    'vtkIOMINC': ('vtkMINCImageReader',),
    'vtkIOPLY': (
        'vtkPLYReader',
        'vtkPLYWriter',
    ),
    'vtkIOParallel': (
        'vtkEnSightWriter',
        'vtkMultiBlockPLOT3DReader',
        'vtkNek5000Reader',
        'vtkPDataSetReader',
        'vtkPOpenFOAMReader',
        'vtkPlot3DMetaReader',
    ),
    'vtkIOParallelExodus': ('vtkPExodusIIReader',),
    'vtkIOParallelXML': ('vtkXMLPartitionedDataSetWriter',),
    'vtkIOSegY': ('vtkSegYReader',),
    'vtkIOXML': (
        'vtkXMLImageDataReader',
        'vtkXMLImageDataWriter',
        'vtkXMLMultiBlockDataReader',
        'vtkXMLMultiBlockDataWriter',
        'vtkXMLPImageDataReader',
        'vtkXMLPRectilinearGridReader',
        'vtkXMLPUnstructuredGridReader',
        'vtkXMLPartitionedDataSetReader',
        'vtkXMLPolyDataReader',
        'vtkXMLPolyDataWriter',
        'vtkXMLRectilinearGridReader',
        'vtkXMLRectilinearGridWriter',
        'vtkXMLStructuredGridReader',
        'vtkXMLStructuredGridWriter',
        'vtkXMLTableReader',
        'vtkXMLTableWriter',
        'vtkXMLUnstructuredGridReader',
        'vtkXMLUnstructuredGridWriter',
    ),
    'vtkIOXdmf2': ('vtkXdmfReader',),
    'vtkImagingCore': (
        'vtkAbstractImageInterpolator',
        'vtkExtractVOI',
        'vtkImageBSplineCoefficients',
        'vtkImageBSplineInterpolator',
        'vtkImageBinaryThreshold',
        'vtkImageConstantPad',
        'vtkImageDifference',
        'vtkImageExtractComponents',
        'vtkImageFlip',
        'vtkImageInterpolator',
        'vtkImageMirrorPad',
        'vtkImageResize',
        'vtkImageSincInterpolator',
        'vtkImageThreshold',
        'vtkImageWrapPad',
        'vtkRTAnalyticSource',
    ),
    'vtkImagingFourier': (
        'vtkImageButterworthHighPass',
        'vtkImageButterworthLowPass',
        'vtkImageFFT',
        'vtkImageRFFT',
    ),
    'vtkImagingGeneral': (
        'vtkImageGaussianSmooth',
        'vtkImageMedian3D',
    ),
    'vtkImagingHybrid': (
        'vtkGaussianSplatter',
        'vtkSampleFunction',
        'vtkSurfaceReconstructionFilter',
    ),
    'vtkImagingMorphological': (
        'vtkImageConnectivityFilter',
        'vtkImageContinuousDilate3D',
        'vtkImageContinuousErode3D',
        'vtkImageDilateErode3D',
    ),
    'vtkImagingSources': (
        'vtkImageEllipsoidSource',
        'vtkImageGaussianSource',
        'vtkImageGridSource',
        'vtkImageMandelbrotSource',
        'vtkImageNoiseSource',
        'vtkImageSinusoidSource',
    ),
    'vtkImagingStencil': (
        'vtkImageStencilToImage',
        'vtkPolyDataToImageStencil',
    ),
    'vtkParallelCore': ('vtkDummyController',),
}

# Rendering modules for pyvista's plotting API
_PLOTTING_MODULES: dict[str, tuple[str, ...]] = {
    'vtkChartsCore': (
        'vtkAxis',
        'vtkChart',
        'vtkChartBox',
        'vtkChartPie',
        'vtkChartXY',
        'vtkChartXYZ',
        'vtkPlotArea',
        'vtkPlotBar',
        'vtkPlotBox',
        'vtkPlotLine',
        'vtkPlotLine3D',
        'vtkPlotPie',
        'vtkPlotPoints',
        'vtkPlotPoints3D',
        'vtkPlotStacked',
        'vtkPlotSurface',
    ),
    'vtkCommonColor': (
        'vtkColorSeries',
        'vtkNamedColors',
    ),
    'vtkInteractionStyle': (
        'vtkInteractorStyleImage',
        'vtkInteractorStyleJoystickActor',
        'vtkInteractorStyleJoystickCamera',
        'vtkInteractorStyleRubberBand2D',
        'vtkInteractorStyleRubberBandPick',
        'vtkInteractorStyleRubberBandZoom',
        'vtkInteractorStyleTerrain',
        'vtkInteractorStyleTrackballActor',
        'vtkInteractorStyleTrackballCamera',
    ),
    'vtkInteractionWidgets': (
        'vtkBoxWidget',
        'vtkButtonWidget',
        'vtkCamera3DRepresentation',
        'vtkCamera3DWidget',
        'vtkCameraOrientationWidget',
        'vtkDistanceRepresentation3D',
        'vtkDistanceWidget',
        'vtkImplicitPlaneWidget',
        'vtkLineWidget',
        'vtkLogoRepresentation',
        'vtkLogoWidget',
        'vtkOrientationMarkerWidget',
        'vtkPlaneWidget',
        'vtkPointHandleRepresentation3D',
        'vtkResliceCursorPicker',
        'vtkScalarBarWidget',
        'vtkSliderRepresentation2D',
        'vtkSliderWidget',
        'vtkSphereWidget',
        'vtkSplineWidget',
        'vtkTexturedButtonRepresentation2D',
    ),
    'vtkRenderingAnnotation': (
        'vtkAnnotatedCubeActor',
        'vtkAxesActor',
        'vtkAxisActor',
        'vtkAxisActor2D',
        'vtkCornerAnnotation',
        'vtkCubeAxesActor',
        'vtkLegendBoxActor',
        'vtkLegendScaleActor',
        'vtkScalarBarActor',
    ),
    'vtkRenderingContext2D': (
        'vtkBlockItem',
        'vtkBrush',
        'vtkContext2D',
        'vtkContextActor',
        'vtkContextScene',
        'vtkImageItem',
        'vtkPen',
    ),
    'vtkRenderingCore': (
        'VTK_RESOLVE_OFF',
        'VTK_RESOLVE_POLYGON_OFFSET',
        'VTK_RESOLVE_SHIFT_ZBUFFER',
        'vtkAbstractMapper',
        'vtkActor',
        'vtkActor2D',
        'vtkAreaPicker',
        'vtkCamera',
        'vtkCellPicker',
        'vtkColorTransferFunction',
        'vtkCompositeDataDisplayAttributes',
        'vtkCompositePolyDataMapper',
        'vtkCoordinate',
        'vtkDataSetMapper',
        'vtkFollower',
        'vtkHardwarePicker',
        'vtkImageActor',
        'vtkInteractorStyle',
        'vtkLight',
        'vtkLightActor',
        'vtkLightKit',
        'vtkMapper',
        'vtkPointGaussianMapper',
        'vtkPointPicker',
        'vtkPolyDataMapper',
        'vtkPolyDataMapper2D',
        'vtkProp',
        'vtkProp3D',
        'vtkPropAssembly',
        'vtkPropCollection',
        'vtkPropPicker',
        'vtkProperty',
        'vtkRenderWindow',
        'vtkRenderWindowInteractor',
        'vtkRenderedAreaPicker',
        'vtkRenderer',
        'vtkScenePicker',
        'vtkSelectVisiblePoints',
        'vtkSkybox',
        'vtkTextActor',
        'vtkTextProperty',
        'vtkTexture',
        'vtkViewport',
        'vtkVolume',
        'vtkVolumeProperty',
        'vtkWindowToImageFilter',
        'vtkWorldPointPicker',
    ),
    'vtkRenderingFreeType': (
        'vtkMathTextFreeTypeTextRenderer',
        'vtkVectorText',
    ),
    'vtkRenderingLabel': (
        'vtkLabelPlacementMapper',
        'vtkPointSetToLabelHierarchy',
    ),
    'vtkRenderingUI': ('vtkGenericRenderWindowInteractor',),
    'vtkRenderingVolume': (
        'vtkFixedPointVolumeRayCastMapper',
        'vtkGPUVolumeRayCastMapper',
        'vtkUnstructuredGridVolumeRayCastMapper',
        'vtkVolumeMapper',
        'vtkVolumePicker',
    ),
    'vtkViewsContext2D': ('vtkContextInteractorStyle',),
}

# GL-dependent imports from VTK.
# These are the modules within VTK requiring libGL that must be loaded
# across pyvista's plotting API. These imports have the potential to
# raise an ImportError if the user does not have libGL installed.
#
#     ImportError: libGL.so.1: cannot open shared object file: No such file or directory
_OPENGL_MODULES: dict[str, tuple[str, ...]] = {
    'vtkRenderingOpenGL2': (
        'vtkCameraPass',
        'vtkCompositePolyDataMapper2',  # optional (contextlib.suppress)
        'vtkDepthOfFieldPass',
        'vtkEDLShading',
        'vtkEGLRenderWindow',  # optional (Linux EGL builds)
        'vtkGaussianBlurPass',
        'vtkOpenGLFXAAPass',
        'vtkOpenGLHardwareSelector',
        'vtkOpenGLRenderer',
        'vtkOpenGLSkybox',
        'vtkOpenGLTexture',
        'vtkPBRIrradianceTexture',
        'vtkPBRLUTTexture',
        'vtkPBRPrefilterTexture',
        'vtkRenderStepsPass',
        'vtkSSAAPass',
        'vtkSSAOPass',
        'vtkShader',
        'vtkShadowMapPass',
        'vtkXOpenGLRenderWindow',  # optional (Linux X11 builds)
    ),
    'vtkRenderingVolumeOpenGL2': (
        'vtkOpenGLGPUVolumeRayCastMapper',
        'vtkSmartVolumeMapper',
    ),
}

# Derived mapping: class -> module
_VTK_CLASS_TO_MODULE: dict[str, str] = {
    cls: module
    for module, classes in (_CORE_MODULES | _PLOTTING_MODULES | _OPENGL_MODULES).items()
    for cls in classes
}


def _import_from(module_name: str, class_name: str) -> Any:
    """Import ``class_name`` for the irregular loaders below.

    ``module_name`` is ignored on a flat backend (the class resolves off the root);
    a missing module or attribute raises ``ImportError``, as ``from m import c`` does.
    """
    root = importlib.import_module(
        _VTK_ROOT if _VTK_ROOT_IS_FLAT else f'{_VTK_ROOT}.{module_name}'
    )
    try:
        return getattr(root, class_name)
    except AttributeError as e:  # match `from m import c` (raises ImportError)
        raise ImportError(str(e)) from e


def __getattr__(name: str):
    """Lazy attribute access.

    VTK modules are only imported when first accessed.
    """
    # Private/dunder lookups are this module's own (or interpreter probes); don't
    # forward them to the backend (would turn AttributeError into a stray ImportError).
    if name.startswith('_'):
        raise AttributeError(name)

    # Handle special cases
    if importer := _SPECIAL_LOADERS.get(name):
        obj = importer()
    elif _VTK_ROOT_IS_FLAT:
        # Flat backend (cvista): resolve the class by NAME off the root. The mapping
        # is still consulted for MEMBERSHIP (an unmapped name stays an AttributeError,
        # as on stock VTK); only its module value -- the part that churns -- is unused.
        if name not in _VTK_CLASS_TO_MODULE:
            msg = (
                f"{name!r} is not defined in PyVista's vtk namespace.\n"
                f'Developers should add a new `module:{name}` mapping to the `_vtk` module.'
            )
            raise AttributeError(msg)
        try:
            obj = getattr(importlib.import_module(_VTK_ROOT), name)
        except (ImportError, AttributeError) as e:
            msg = (
                f'Cannot import name {name!r} from {_VTK_ROOT!r}.\n'
                'The cause is likely attributable to VTK version or a custom VTK build.'
            )
            raise ImportError(msg) from e
    else:  # Stock vtkmodules: lazily import based on the module mapping
        module_name = _VTK_CLASS_TO_MODULE.get(name)
        if module_name is None:
            msg = (
                f"{name!r} is not defined in PyVista's vtk namespace.\n"
                f'Developers should add a new `module:{name}` mapping to the `_vtk` module.'
            )
            raise AttributeError(msg)

        # Attempt to import the vtkmodule and the desired attribute
        # Convert module or attribute errors into a similar message that would otherwise be
        # seen when doing `from vtkmodules.vtkModule import vtkClass`
        module_full_name = f'{_VTK_ROOT}.{module_name}'
        error_msg = (
            f'Cannot import name {name!r} from {module_full_name!r}.\n'
            'The cause is likely attributable to VTK version or a custom VTK build.'
        )
        try:
            module = importlib.import_module(module_full_name)
            obj = getattr(module, name)
        except (ModuleNotFoundError, AttributeError) as e:
            raise ImportError(error_msg) from e

    # Cache object for next access
    globals()[name] = obj
    return obj


def has_attr(name: str) -> bool:
    """Return ``True`` if ``name`` resolves to a VTK class on this build.

    ``hasattr(_vtk, 'X')`` does not work as expected because the lazy
    ``__getattr__`` raises ``ImportError`` (not ``AttributeError``) when a
    class is mapped but missing from the underlying ``vtkmodules`` module on
    the installed VTK build. ``hasattr`` only catches ``AttributeError``, so
    the raised ``ImportError`` propagates and breaks version-probe call sites.
    Use this helper instead.

    Parameters
    ----------
    name : str
        Attribute name to probe on the ``_vtk`` namespace.

    Returns
    -------
    bool
        ``True`` if the attribute resolves on this VTK build, ``False`` if it
        is missing or its underlying ``vtkmodules`` module is missing.

    """
    if name in globals():
        return True
    try:
        __getattr__(name)
    except (AttributeError, ImportError):
        return False
    return True


def import_all(*, suppress_import_errors: bool = True):
    """Eagerly import all vtk classes used by PyVista.

    Parameters
    ----------
    suppress_import_errors : bool, default: True
        Skip classes that fail to import.

    """
    for name in (*list(_VTK_CLASS_TO_MODULE.keys()), *list(_SPECIAL_LOADERS.keys())):
        if suppress_import_errors:
            # Use has_attr to suppress import errors
            has_attr(name)
        else:
            __getattr__(name)


# Specialized loading functions for irregular imports


def _import_vtkPythonItem():  # noqa: N802
    try:
        return _import_from('vtkPythonContext2D', 'vtkPythonItem')
    except ImportError:  # pragma: no cover
        # Suppress for ParaView shell https://github.com/pyvista/pyvista/issues/3224

        class vtkPythonItem:  # noqa: N801
            """Empty placeholder."""

            def __init__(self) -> None:  # pragma: no cover
                """Raise version error on init."""
                from pyvista.core.errors import VTKVersionError

                msg = 'Chart backgrounds require the vtkPythonContext2D module'
                raise VTKVersionError(msg)

    return vtkPythonItem


def _import_vtkCellTypeUtilities():  # noqa: N802
    try:  # Introduced VTK 9.6.0
        return _import_from('vtkCommonDataModel', 'vtkCellTypeUtilities')
    except ImportError:
        return _import_from('vtkCommonDataModel', 'vtkCellTypes')


def _import_vtkRenderPassCollection():  # noqa: N802
    try:  # Moved in VTK 10.0.0
        return _import_from('vtkRenderingCore', 'vtkRenderPassCollection')
    except ImportError:
        return _import_from('vtkRenderingOpenGL2', 'vtkRenderPassCollection')


def _import_vtkSequencePass():  # noqa: N802
    try:  # Moved in VTK 10.0.0
        return _import_from('vtkRenderingCore', 'vtkSequencePass')
    except ImportError:
        return _import_from('vtkRenderingOpenGL2', 'vtkSequencePass')


_SPECIAL_LOADERS: dict[str, Callable[[], type[Any]]] = {
    'vtkPythonItem': _import_vtkPythonItem,
    'vtkCellTypeUtilities': _import_vtkCellTypeUtilities,
    'vtkRenderPassCollection': _import_vtkRenderPassCollection,
    'vtkSequencePass': _import_vtkSequencePass,
}


# Handing Python a C++ object from a module that has not been imported binds that class
# name to a base class for the rest of the process, so a documentation build -- whose
# examples run in worker processes of their own -- resolves every class up front.
if os.environ.get('PYVISTA_BUILDING_GALLERY', 'false').lower() == 'true':
    import_all()
