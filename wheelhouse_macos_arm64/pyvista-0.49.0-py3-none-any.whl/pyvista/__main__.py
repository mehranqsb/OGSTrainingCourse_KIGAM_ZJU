"""PyVista's command-line interface."""

from __future__ import annotations

import warnings

from pyvista.core.errors import PyVistaDeprecationWarning

from ._cli import CLI_APP


def main(argv: list[str] | str | None = None) -> None:
    """PyVista Command-Line Interface entry point.

    Parameters
    ----------
    argv : list[str] | str, optional
        Command-line arguments. Defaults to ``sys.argv[1:]``.

    """
    # Ignore warnings emitted because arguments are passed positionally by the
    # inspect module. See https://docs.python.org/3/library/inspect.html#inspect.BoundArguments.kwargs
    # and https://github.com/BrianPugh/cyclopts/issues/567
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', category=PyVistaDeprecationWarning)
        result = CLI_APP(tokens=argv)

    if result is not None:
        print(result)  # noqa: T201


if __name__ == '__main__':
    main()
