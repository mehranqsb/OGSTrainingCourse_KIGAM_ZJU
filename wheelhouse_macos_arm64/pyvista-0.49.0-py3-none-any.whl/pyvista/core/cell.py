"""Contains the pyvista.Cell class."""

from __future__ import annotations

from typing import TYPE_CHECKING
from typing import cast

import numpy as np

import pyvista as pv
from pyvista import _vtk
from pyvista._deprecate_positional_args import _deprecate_positional_args
from pyvista._warn_external import warn_external
from pyvista.core._vtk_utilities import _SETDATA_TAKES_OWNERSHIP
from pyvista.core._vtk_utilities import _SUPPORTS_FIXED_SIZE_STORAGE
from pyvista.core._vtk_utilities import DisableVtkSnakeCase
from pyvista.core._vtk_utilities import vtkPyVistaOverride

from ._typing_core import BoundsTuple
from .celltype import CellType
from .dataobject import DataObject
from .errors import CellSizeError
from .errors import PyVistaDeprecationWarning
from .utilities.cells import numpy_to_idarr
from .utilities.misc import _BoundsSizeMixin
from .utilities.misc import _NoNewAttrMixin

if TYPE_CHECKING:
    from typing import Any

    from typing_extensions import Self

    from pyvista import PolyData
    from pyvista import UnstructuredGrid

    from ._typing_core import CellsLike
    from ._typing_core import MatrixLike
    from ._typing_core import NumpyArray
    from ._typing_core import VectorLike


def _get_vtk_id_type() -> type[np.int32 | np.longlong]:
    """Return the NumPy datatype responding to :vtk:`vtkIdTypeArray`.

    The 64-bit case returns :class:`numpy.longlong` (C ``long long``) rather than
    :class:`numpy.int64`. ``vtkIdType`` is C ``long long`` on every platform, but on
    LP64 (Linux/macOS) NumPy binds the name ``int64`` to C ``long`` instead, which is
    a *distinct* scalar type. Since VTK 9.7 the NumPy-to-VTK mapping follows the
    underlying C type, so ``np.int64`` there resolves to ``VTK_LONG`` and only
    ``np.longlong`` resolves to ``VTK_ID_TYPE``. ``longlong`` maps to ``VTK_LONG_LONG``
    on all supported VTK versions and platforms, so it is correct either way.

    The two compare equal as ``dtypes`` and have identical width, so this is invisible to
    value comparisons; it only affects which VTK array class conversions produce.
    """
    VTK_ID_TYPE_SIZE = _vtk.vtkIdTypeArray().GetDataTypeSize()
    if VTK_ID_TYPE_SIZE == 4:
        return np.int32
    elif VTK_ID_TYPE_SIZE == 8:
        return np.longlong
    return np.int32


class Cell(_BoundsSizeMixin, DataObject, _vtk.vtkGenericCell):
    """Wrapping of :vtk:`vtkCell`.

    This class provides the capability to access a given cell topology and can
    be useful when walking through a cell's individual faces or investigating
    cell properties.

    Parameters
    ----------
    vtk_cell : :vtk:`vtkCell`, optional
        The vtk object to wrap as Cell, that must be of :vtk:`vtkCell` type.

    cell_type : int, optional
        VTK cell type. Determined from ``vtk_cell`` if not input.

    deep : bool, default: False
        Perform a deep copy of the original cell.

    See Also
    --------
    pyvista.CellType

    Notes
    -----
    Accessing individual cells from a :class:`pyvista.DataSet` using this class
    will be much slower than accessing bulk data from the
    :attr:`pyvista.PolyData.faces` or :attr:`pyvista.UnstructuredGrid.cells` attributes.

    Also note that the cell object is a deep copy of the original cell and
    is unassociated with the original cell. Changing any data of
    that cell (for example, :attr:`pyvista.Cell.points`) will not change the original dataset.

    Examples
    --------
    Get cell 0 from a :class:`pyvista.PolyData`.

    >>> import pyvista as pv
    >>> mesh = pv.Sphere()
    >>> cell = mesh.get_cell(0)
    >>> cell  # doctest: +SKIP
    Cell (0x7fa760075a10)
      Type:       <CellType.TRIANGLE: 5>
      Linear:     True
      Dimension:  2
      N Points:   3
      N Faces:    0
      N Edges:    3
      X Bounds:   -5.406e-02, -5.551e-17
      Y Bounds:   0.000e+00, 1.124e-02
      Z Bounds:   -5.000e-01, -4.971e-01

    Get cell 0 from a :class:`pyvista.UnstructuredGrid`.

    >>> from pyvista import examples
    >>> mesh = examples.load_hexbeam()
    >>> cell = mesh.get_cell(0)
    >>> cell  # doctest: +SKIP
    Cell (0x7fdc71a3c210)
      Type:       <CellType.HEXAHEDRON: 12>
      Linear:     True
      Dimension:  3
      N Points:   8
      N Faces:    6
      N Edges:    12
      X Bounds:   0.000e+00, 5.000e-01
      Y Bounds:   0.000e+00, 5.000e-01
      Z Bounds:   0.000e+00, 5.000e-01

    """

    @_deprecate_positional_args(allowed=['vtk_cell', 'cell_type'])
    def __init__(
        self: Self,
        vtk_cell: _vtk.vtkCell | None = None,
        cell_type: CellType | None = None,
        deep: bool = False,  # noqa: FBT001, FBT002
    ) -> None:
        """Initialize the cell."""
        super().__init__()
        if vtk_cell is not None:
            if not isinstance(vtk_cell, _vtk.vtkCell):
                msg = f'`vtk_cell` must be a vtkCell, not {type(vtk_cell)}'  # type: ignore[unreachable]
                raise TypeError(msg)
            # cell type must be set first before deep or shallow copy
            if cell_type is None:
                self.SetCellType(vtk_cell.GetCellType())
            else:
                self.SetCellType(cell_type)

            if deep:
                self.DeepCopy(vtk_cell)
            else:
                self.ShallowCopy(vtk_cell)

    @property
    def type(self: Self) -> CellType:
        """Get the cell type from the enum :class:`pyvista.CellType`.

        Returns
        -------
        pyvista.CellType
            Type of cell.

        Examples
        --------
        >>> import pyvista as pv
        >>> mesh = pv.Sphere()
        >>> mesh.get_cell(0).type
        <CellType.TRIANGLE: 5>

        """
        return CellType(self.GetCellType())

    @property
    def is_linear(self: Self) -> bool:
        """Return if the cell is linear.

        See Also
        --------
        pyvista.CellType.is_linear

        Returns
        -------
        bool
            If the cell is linear.

        Examples
        --------
        >>> import pyvista as pv
        >>> mesh = pv.Sphere()
        >>> mesh.get_cell(0).is_linear
        True

        """
        return bool(self.IsLinear())

    def plot(self: Self, **kwargs) -> None:
        """Plot this cell.

        Parameters
        ----------
        **kwargs : dict, optional
            See :func:`pyvista.plot` for a description of the optional keyword
            arguments.

        Examples
        --------
        >>> from pyvista import examples
        >>> mesh = examples.load_hexbeam()
        >>> cell = mesh.get_cell(0)
        >>> cell.plot()

        """
        self.cast_to_unstructured_grid().plot(**kwargs)

    def cast_to_polydata(self: Self) -> PolyData:
        """Cast this cell to PolyData.

        Can only be used for 0D, 1D, or 2D cells.

        Returns
        -------
        pyvista.PolyData
            This cell cast to a :class:`pyvista.PolyData`.

        Examples
        --------
        >>> from pyvista import examples
        >>> mesh = examples.load_sphere()
        >>> cell = mesh.get_cell(0)
        >>> grid = cell.cast_to_polydata()
        >>> grid  # doctest: +SKIP
        PolyData (0x7f09ae437b80)
          N Cells:    1
          N Points:   3
          N Strips:   0
           X Bounds:   0.000e+00, 1.000e+01
          Y Bounds:   0.000e+00, 2.500e+01
          Z Bounds:   -1.270e+02, -1.250e+02
          N Arrays:   0

        """
        cells = [len(self.point_ids), *list(range(len(self.point_ids)))]
        if self.dimension == 0:
            return pv.PolyData(self.points.copy(), verts=cells)
        if self.dimension == 1:
            return pv.PolyData(self.points.copy(), lines=cells)
        if self.dimension == 2:
            if self.type == CellType.TRIANGLE_STRIP:
                return pv.PolyData(self.points.copy(), strips=cells)
            else:
                return pv.PolyData(self.points.copy(), faces=cells)
        else:
            msg = f'3D cells cannot be cast to PolyData: got cell type {self.type}'
            raise ValueError(msg)

    def cast_to_unstructured_grid(self: Self) -> UnstructuredGrid:
        """Cast this cell to an unstructured grid.

        Returns
        -------
        pyvista.UnstructuredGrid
            This cell cast to a :class:`pyvista.UnstructuredGrid`.

        Examples
        --------
        >>> from pyvista import examples
        >>> mesh = examples.load_hexbeam()
        >>> cell = mesh.get_cell(0)
        >>> grid = cell.cast_to_unstructured_grid()
        >>> grid  # doctest: +SKIP
        UnstructuredGrid (0x7f9383619540)
          N Cells:      1
          N Points:     8
          X Bounds:     0.000e+00, 5.000e-01
          Y Bounds:     0.000e+00, 5.000e-01
          Z Bounds:     0.000e+00, 5.000e-01
          N Arrays:     0

        """
        if self.type == CellType.POLYHEDRON:
            # construct from faces
            cell_ids = [self.n_faces]
            for face in self.faces:
                cell_ids.append(len(face.point_ids))
                cell_ids.extend(self.point_ids.index(i) for i in face.point_ids)
            cell_ids.insert(0, len(cell_ids))
        else:
            cell_ids = [len(self.point_ids), *list(range(len(self.point_ids)))]
        return pv.UnstructuredGrid(
            cell_ids,
            [int(self.type)],
            self.points.copy(),
        )

    @property
    def dimension(self: Self) -> int:
        """Return the cell dimension.

        This returns the dimensionality of the cell. For example, 1 for an edge,
        2 for a triangle, and 3 for a tetrahedron.

        See Also
        --------
        pyvista.CellType.dimension

        Returns
        -------
        int
            The cell dimension.

        Examples
        --------
        >>> import pyvista as pv
        >>> mesh = pv.Sphere()
        >>> mesh.get_cell(0).dimension
        2

        """
        return self.GetCellDimension()

    @property
    def n_points(self: Self) -> int:
        """Get the number of points composing the cell.

        See Also
        --------
        pyvista.CellType.n_points

        Returns
        -------
        int
            The number of points.

        Examples
        --------
        >>> import pyvista as pv
        >>> mesh = pv.Sphere()
        >>> mesh.get_cell(0).n_points
        3

        """
        return self.GetNumberOfPoints()

    @property
    def n_faces(self: Self) -> int:
        """Get the number of faces composing the cell.

        See Also
        --------
        pyvista.CellType.n_faces

        Returns
        -------
        int
            The number of faces.

        Examples
        --------
        >>> from pyvista.examples.cells import Tetrahedron
        >>> mesh = Tetrahedron()
        >>> mesh.get_cell(0).n_faces
        4

        """
        return self.GetNumberOfFaces()

    @property
    def n_edges(self: Self) -> int:
        """Get the number of edges composing the cell.

        See Also
        --------
        pyvista.CellType.n_edges

        Returns
        -------
        int
            The number of edges composing the cell.

        Examples
        --------
        >>> import pyvista as pv
        >>> mesh = pv.Sphere()
        >>> mesh.get_cell(0).n_edges
        3

        """
        return self.GetNumberOfEdges()

    @property
    def point_ids(self: Self) -> list[int]:
        """Get the point IDs composing the cell.

        Returns
        -------
        list[int]
            The point IDs composing the cell.

        Examples
        --------
        >>> import pyvista as pv
        >>> mesh = pv.Sphere()
        >>> mesh.get_cell(0).point_ids
        [2, 30, 0]

        """
        point_ids = self.GetPointIds()
        return [point_ids.GetId(i) for i in range(point_ids.GetNumberOfIds())]

    @property
    def points(self: Self) -> NumpyArray[float]:
        """Get the point coordinates of the cell.

        Returns
        -------
        np.ndarray
            The point coordinates of the cell.

        Examples
        --------
        >>> import pyvista as pv
        >>> mesh = pv.Sphere()
        >>> mesh.get_cell(0).points
        array([[0.05405951, 0.        , 0.49706897],
               [0.05287818, 0.0112396 , 0.49706897],
               [0.        , 0.        , 0.5       ]])

        """
        return _vtk.vtk_to_numpy(self.GetPoints().GetData())

    def get_edge(self: Self, index: int) -> Cell:
        """Get the edge at ``index`` composing the cell.

        Parameters
        ----------
        index : int
            Edge ID.

        Returns
        -------
        pyvista.Cell
            Edge given by ``index``.

        Examples
        --------
        Extract a single edge from a face and output the IDs of the edge
        points.

        >>> import pyvista as pv
        >>> mesh = pv.Sphere()
        >>> cell = mesh.get_cell(0)
        >>> edge = cell.get_edge(0)
        >>> edge.point_ids
        [2, 30]

        """
        if index + 1 > self.n_edges:
            msg = f'Invalid index {index} for a cell with {self.n_edges} edges.'
            raise IndexError(msg)

        # must deep copy here as multiple sequental calls to GetEdge overwrite
        # the underlying pointer
        return Cell(self.GetEdge(index), deep=True)  # type: ignore[abstract]

    @property
    def edges(self: Self) -> list[Cell]:
        """Return a list of edges composing the cell.

        Returns
        -------
        list[Cell]
            A list of edges composing the cell.

        Examples
        --------
        >>> from pyvista.examples.cells import Hexahedron
        >>> mesh = Hexahedron()
        >>> cell = mesh.get_cell(0)
        >>> edges = cell.edges
        >>> len(edges)
        12

        """
        return [self.get_edge(i) for i in range(self.n_edges)]

    @property
    def faces(self: Self) -> list[Cell]:
        """Return a list of faces composing the cell.

        Returns
        -------
        list[Cell]
            A list of faces composing the cell.

        Examples
        --------
        >>> from pyvista.examples.cells import Tetrahedron
        >>> mesh = Tetrahedron()
        >>> cell = mesh.get_cell(0)
        >>> faces = cell.faces
        >>> len(faces)
        4

        """
        return [self.get_face(i) for i in range(self.n_faces)]

    def get_face(self: Self, index: int) -> Cell:
        """Get the face at ``index`` composing the cell.

        Parameters
        ----------
        index : int
            Face ID.

        Returns
        -------
        pyvista.Cell
            Face given by ``index``.

        Examples
        --------
        Return the face IDs composing the first face of an example tetrahedron.

        >>> from pyvista.examples.cells import Tetrahedron
        >>> mesh = Tetrahedron()
        >>> cell = mesh.get_cell(0)
        >>> face = cell.get_face(0)
        >>> face.point_ids
        [0, 1, 3]

        """
        # must deep copy here as sequental calls overwrite the underlying pointer
        if index + 1 > self.n_faces:
            msg = f'Invalid index {index} for a cell with {self.n_faces} faces.'
            raise IndexError(msg)

        # must deep copy here as multiple sequental calls to GetFace overwrite
        # the underlying pointer
        cell = self.GetFace(index)
        return Cell(cell, deep=True, cell_type=cast('CellType', cell.GetCellType()))  # type: ignore[abstract]

    @property
    def bounds(self: Self) -> BoundsTuple:
        """Get the cell bounds in ``(x_min, x_max, y_min, y_max, z_min, z_max)``.

        Returns
        -------
        BoundsTuple
            The cell bounds in ``(x_min, x_max, y_min, y_max, z_min, z_max)``.

        Examples
        --------
        >>> import pyvista as pv
        >>> mesh = pv.Sphere()
        >>> mesh.get_cell(0).bounds
        BoundsTuple(x_min = 0.0,
                    x_max = 0.05405950918793678,
                    y_min = 0.0,
                    y_max = 0.011239604093134403,
                    z_min = 0.49706897139549255,
                    z_max = 0.5)

        """
        return BoundsTuple(*self.GetBounds())

    @property
    def center(self: Self) -> tuple[float, float, float]:
        """Get the center of the cell.

        Uses parametric coordinate center to determine x-y-z center.

        Returns
        -------
        tuple[float, float, float]
            The center of the cell.

        Examples
        --------
        >>> import pyvista as pv
        >>> mesh = pv.Sphere()
        >>> mesh.get_cell(0).center
        (0.03564589594801267, 0.0037465346977114677, 0.49804598093032837)

        """
        para_center = [0.0, 0.0, 0.0]
        sub_id = self.GetParametricCenter(para_center)
        # EvaluateLocation requires mutable sub_id
        sub_id = _vtk.mutable(sub_id)  # type: ignore[assignment]
        # center and weights are returned from EvaluateLocation
        center = [0.0, 0.0, 0.0]
        weights = [0.0] * self.n_points
        self.EvaluateLocation(sub_id, para_center, center, weights)
        return cast('tuple[float, float, float]', tuple(center))

    def _get_attrs(self: Self) -> list[tuple[str, Any, str]]:
        """Return the representation methods (internal helper)."""
        attrs = []
        attrs.append(('Type', repr(self.type), '{}' * len(repr(self.type))))
        attrs.append(('Linear', self.is_linear, '{}'))  # type: ignore[arg-type]
        attrs.append(('Dimension', self.dimension, '{}'))  # type: ignore[arg-type]
        attrs.append(('N Points', self.n_points, '{}'))  # type: ignore[arg-type]
        attrs.append(('N Faces', self.n_faces, '{}'))  # type: ignore[arg-type]
        attrs.append(('N Edges', self.n_edges, '{}'))  # type: ignore[arg-type]
        bds = self.bounds
        fmt = f'{pv.FLOAT_FORMAT}, {pv.FLOAT_FORMAT}'
        attrs.append(('X Bounds', (bds[0], bds[1]), fmt))  # type: ignore[arg-type]
        attrs.append(('Y Bounds', (bds[2], bds[3]), fmt))  # type: ignore[arg-type]
        attrs.append(('Z Bounds', (bds[4], bds[5]), fmt))  # type: ignore[arg-type]

        return attrs

    def __repr__(self: Self) -> str:
        """Return the object representation."""
        return self.head(display=False, html=False)

    def __str__(self: Self) -> str:
        """Return the object string representation."""
        return self.head(display=False, html=False)

    @_deprecate_positional_args
    def copy(self: Self, deep: bool = True) -> Self:  # noqa: FBT001, FBT002
        """Return a copy of the cell.

        Parameters
        ----------
        deep : bool, optional
            When ``True`` makes a full copy of the cell.  When ``False``,
            performs a shallow copy where the new cell still references the
            original cell.

        Returns
        -------
        pyvista.Cell
            Deep or shallow copy of the cell.

        Examples
        --------
        Create a deep copy of the cell and demonstrate it is deep.

        >>> from pyvista.examples.cells import Tetrahedron
        >>> mesh = Tetrahedron()
        >>> cell = mesh.get_cell(0)
        >>> deep_cell = cell.copy(deep=True)
        >>> deep_cell.points[:] = 0
        >>> cell != deep_cell
        True

        Create a shallow copy of the cell and demonstrate it is shallow.

        >>> shallow_cell = cell.copy(deep=False)
        >>> shallow_cell.points[:] = 0
        >>> cell == shallow_cell
        True

        """
        return type(self)(self, deep=deep)


def _expected_legacy_cell_array_size(cells: NumpyArray[int]) -> int | None:
    """Return the array size a well-formed legacy ``[npts, id0, id1, ...]`` array implies.

    Returns ``None`` if a negative point count makes the layout uninterpretable.
    """
    cells = np.ravel(cells)
    size = 0
    pos = 0
    while pos < cells.size:
        npts = int(cells[pos])
        if npts < 0:
            return None
        size += 1 + npts
        pos += 1 + npts
    return size


class CellArray(
    _NoNewAttrMixin,
    DisableVtkSnakeCase,
    vtkPyVistaOverride,
    _vtk.vtkCellArray,
):
    """PyVista wrapping of :vtk:`vtkCellArray`.

    Provides convenience functions to simplify creating a CellArray from
    a NumPy array or list.

    Parameters
    ----------
    cells : np.ndarray or list, optional
        Import an array of data with the legacy :vtk:`vtkCellArray` layout: each
        cell is stored as its point count followed by that many point indices,
        with cells concatenated back-to-back (for example ``[3, 0, 1, 2, 4, 0, 1, 2, 3]``
        for a triangle followed by a quad).

    Examples
    --------
    Create a cell array containing two triangles from the traditional interleaved format

    >>> from pyvista.core.cell import CellArray
    >>> cellarr = CellArray([3, 0, 1, 2, 3, 3, 4, 5])

    Create a cell array containing two triangles from separate offsets and connectivity arrays

    >>> from pyvista.core.cell import CellArray
    >>> offsets = [0, 3, 6]
    >>> connectivity = [0, 1, 2, 3, 4, 5]
    >>> cellarr = CellArray.from_arrays(offsets, connectivity)

    """

    def __init__(
        self: Self,
        cells: CellsLike | None = None,
    ) -> None:
        """Initialize a :vtk:`vtkCellArray`."""
        super().__init__()
        self.__offsets: _vtk.vtkIdTypeArray | None = None
        self.__connectivity: _vtk.vtkIdTypeArray | None = None
        if cells is not None:
            self.cells = cells

    @property
    def cells(self: Self) -> NumpyArray[int]:
        """Return a NumPy array of the cells.

        Returns
        -------
        np.ndarray
            A NumPy array of the cells.

        """
        cells = _vtk.vtkIdTypeArray()
        self.ExportLegacyFormat(cells)
        return _vtk.vtk_to_numpy(cells)

    @cells.setter
    def cells(self: Self, cells: CellsLike) -> None:
        cells = np.asarray(cells)
        vtk_idarr = numpy_to_idarr(cells, deep=False, return_ind=False)
        output = self.ImportLegacyFormat(vtk_idarr)

        # VTK's ImportLegacyFormat started returning a bool (success/corrupt) instead of None
        # https://gitlab.kitware.com/vtk/vtk/-/commit/82af9fa1e5a0ea5c0a827e91672cd42fe09575de
        size_is_valid = (
            self.GetNumberOfCells() + self.GetNumberOfConnectivityIds() == cells.size
            if output is None  # type: ignore[redundant-expr]
            else output
        )
        # https://github.com/pyvista/pyvista/pull/5404
        if not size_is_valid:
            expected_size = _expected_legacy_cell_array_size(cells)
            problem = (
                f'Size ({cells.size}) does not match expected size ({expected_size}).'
                if expected_size is not None
                else 'A cell has a negative number of points.'
            )
            msg = (
                f'Cell array size is invalid. {problem} This is likely'
                ' due to invalid connectivity array.'
            )
            raise CellSizeError(msg)
        self.__offsets = self.__connectivity = None

    @property
    def n_cells(self: Self) -> int:
        """Return the number of cells.

        Returns
        -------
        int
            The number of cells.

        """
        return self.GetNumberOfCells()

    @property
    def cell_offsets(self: Self) -> NumpyArray[int]:  # numpydoc ignore=RT01
        """Return the offsets array.

        The offsets array has ``n_cells + 1`` values and stores the index into
        :attr:`cell_connectivity` at which each cell begins. The point ids of cell ``i``
        are ``cell_connectivity[cell_offsets[i]:cell_offsets[i + 1]]``.

        .. versionadded:: 0.49

        Returns
        -------
        numpy.ndarray
            Array of cell offsets with ``n_cells + 1`` values.

        See Also
        --------
        cell_connectivity
            Point ids that define the cells.

        Notes
        -----
        The returned array is read-only and cannot be modified in place. Assign a new
        array to this property to change the offsets, or use :meth:`from_arrays` to
        replace the offsets and connectivity together.

        Examples
        --------
        >>> import pyvista as pv
        >>> cell_array = pv.CellArray.from_arrays([0, 3, 6], [0, 1, 2, 3, 4, 5])
        >>> cell_array.cell_offsets
        array([0, 3, 6]...)

        Replace the offsets so the same connectivity describes three 2-point cells.

        >>> cell_array.cell_offsets = [0, 2, 4, 6]
        >>> cell_array.n_cells
        3

        """
        return _get_offsets(self)

    @cell_offsets.setter
    def cell_offsets(self: Self, offsets: VectorLike[int]) -> None:
        _set_cell_array_data(self, offsets, self.cell_connectivity)

    @property
    def cell_connectivity(self: Self) -> NumpyArray[int]:  # numpydoc ignore=RT01
        """Return the connectivity array.

        The connectivity array stores the point ids of every cell, one cell after
        another and without any padding. Use :attr:`cell_offsets` to determine where each
        cell begins and ends.

        .. versionadded:: 0.49

        Returns
        -------
        numpy.ndarray
            Point ids that define the cells.

        See Also
        --------
        cell_offsets
            Index into this array at which each cell begins.

        Notes
        -----
        The returned array is read-only and cannot be modified in place. Assign a new
        array to this property to change the connectivity, or use :meth:`from_arrays`
        to replace the offsets and connectivity together. The input is copied, so the
        cell array never aliases an array that may be modified later.

        Where that copy is too expensive, build the cell array with
        :meth:`from_arrays` and ``deep=False`` and keep a reference to the connectivity
        array. The cell array then wraps that array, so writing to it changes the cells
        without any copy. Nothing validates the point ids written this way.

        Examples
        --------
        >>> import pyvista as pv
        >>> cell_array = pv.CellArray.from_arrays([0, 3, 6], [0, 1, 2, 3, 4, 5])
        >>> cell_array.cell_connectivity
        array([0, 1, 2, 3, 4, 5]...)

        >>> cell_array.cell_connectivity = [5, 4, 3, 2, 1, 0]
        >>> cell_array.cell_connectivity
        array([5, 4, 3, 2, 1, 0]...)

        For a cell array large enough that the copy matters, keep the connectivity
        array and edit it in place.

        >>> import numpy as np
        >>> connectivity = np.array([0, 1, 2, 3, 4, 5], dtype=pv.ID_TYPE)
        >>> cell_array = pv.CellArray.from_arrays([0, 3, 6], connectivity, deep=False)
        >>> connectivity[:] = [5, 4, 3, 2, 1, 0]
        >>> cell_array.cell_connectivity
        array([5, 4, 3, 2, 1, 0]...)

        """
        return _get_connectivity(self)

    @cell_connectivity.setter
    def cell_connectivity(self: Self, connectivity: VectorLike[int]) -> None:
        _set_cell_array_data(self, self.cell_offsets, connectivity)

    @property
    def connectivity_array(self: Self) -> NumpyArray[int]:
        """Return the array with the point ids that define the cells' connectivity.

        .. deprecated:: 0.49
            Use :attr:`cell_connectivity` instead. Note that :attr:`cell_connectivity` is
            read-only, whereas this property returns a writeable array.

        Returns
        -------
        np.ndarray
            Array with the point ids that define the cells' connectivity.

        """
        # Deprecated on 0.49.0, error on 0.52.0, estimated removal on 0.53.0
        warn_external(
            '`CellArray.connectivity_array` is deprecated. Use '
            '`CellArray.cell_connectivity` instead, which returns a read-only array.',
            PyVistaDeprecationWarning,
        )
        if pv.version_info >= (0, 52):  # pragma: no cover
            msg = 'Convert this deprecation warning into an error.'
            raise RuntimeError(msg)
        if pv.version_info >= (0, 53):  # pragma: no cover
            msg = 'Remove `CellArray.connectivity_array`.'
            raise RuntimeError(msg)
        return _get_connectivity_array(self)

    @property
    def offset_array(self: Self) -> NumpyArray[int]:
        """Return the array used to store cell offsets.

        .. deprecated:: 0.49
            Use :attr:`cell_offsets` instead. Note that :attr:`cell_offsets` is read-only,
            whereas this property returns a writeable array.

        Returns
        -------
        np.ndarray
            Array used to store cell offsets.

        """
        # Deprecated on 0.49.0, error on 0.52.0, estimated removal on 0.53.0
        warn_external(
            '`CellArray.offset_array` is deprecated. Use `CellArray.cell_offsets` '
            'instead, which returns a read-only array.',
            PyVistaDeprecationWarning,
        )
        if pv.version_info >= (0, 52):  # pragma: no cover
            msg = 'Convert this deprecation warning into an error.'
            raise RuntimeError(msg)
        if pv.version_info >= (0, 53):  # pragma: no cover
            msg = 'Remove `CellArray.offset_array`.'
            raise RuntimeError(msg)
        return _get_offset_array(self)

    def _set_data(
        self: Self,
        offsets: MatrixLike[int],
        connectivity: MatrixLike[int],
        *,
        deep: bool = False,
    ) -> None:
        """Set the offsets and connectivity arrays."""
        offsets = np.asarray(offsets)
        connectivity = np.asarray(connectivity)

        # ``vtkCellArray`` natively supports 32-bit storage (VTK >= 9). When both
        # arrays are already ``int32`` we preserve that instead of casting up to
        # ``pv.ID_TYPE`` (64-bit), which avoids copying and doubling the memory of
        # large offset/connectivity arrays. See https://github.com/pyvista/pyvista/issues/8477
        if offsets.dtype == np.int32 and connectivity.dtype == np.int32:
            vtk_offsets = _vtk.numpy_to_vtk(np.ascontiguousarray(offsets.ravel()), deep=deep)
            vtk_connectivity = _vtk.numpy_to_vtk(
                np.ascontiguousarray(connectivity.ravel()), deep=deep
            )
            self.Use32BitStorage()
        else:
            vtk_offsets = numpy_to_idarr(offsets, deep=deep)
            vtk_connectivity = numpy_to_idarr(connectivity, deep=deep)
        self.SetData(vtk_offsets, vtk_connectivity)

        # Only pre-9.6 VTK needs this: there SetData does not reference the arrays, so
        # dropping them here frees the buffers out from under us. Newer VTK does own
        # them, and stashing anyway leaks both via the ghost __dict__ (see #8873).
        if not _SETDATA_TAKES_OWNERSHIP:
            self.__offsets = vtk_offsets
            self.__connectivity = vtk_connectivity

    def _set_data_fixed_size(
        self: Self,
        cell_size: int,
        connectivity: MatrixLike[int],
        *,
        deep: bool = False,
    ) -> None:
        """Set fixed-size cell connectivity without an explicit offset array."""
        connectivity = np.asarray(connectivity)

        if connectivity.dtype == np.int32:
            vtk_connectivity = _vtk.numpy_to_vtk(
                np.ascontiguousarray(connectivity.ravel()), deep=deep
            )
            self.Use32BitStorage()
        else:
            vtk_connectivity = numpy_to_idarr(connectivity, deep=deep)
        # No stash needed as in _set_data: fixed-size storage implies VTK >= 9.6.2, which
        # always owns the array
        self.SetData(cell_size, vtk_connectivity)

    @staticmethod
    @_deprecate_positional_args(allowed=['offsets', 'connectivity'])
    def from_arrays(
        offsets: MatrixLike[int],
        connectivity: MatrixLike[int],
        deep: bool = False,  # noqa: FBT001, FBT002
    ) -> CellArray:
        """Construct a CellArray from offsets and connectivity arrays.

        Parameters
        ----------
        offsets : MatrixLike[int]
            Offsets array of length ``n_cells + 1``.

        connectivity : MatrixLike[int]
            Connectivity array.

        deep : bool, default: False
            Whether to deep copy the array data into the vtk arrays.

        Returns
        -------
        CellArray
            Constructed CellArray.

        """
        cellarr = CellArray()
        cellarr._set_data(offsets, connectivity, deep=deep)
        return cellarr

    @property
    def regular_cells(self: Self) -> NumpyArray[int]:
        """Return a (``n_cells``, cell_size)-shaped array of point indices for equal-sized faces.

        Returns
        -------
        numpy.ndarray
            Array of face indices of shape (``n_cells``, ``cell_size``).

        Notes
        -----
        This property does not validate that the cells are all
        actually the same size. If they're not, this property may either
        raise a ``ValueError`` or silently return an incorrect array.

        """
        return _get_regular_cells(self)

    @classmethod
    @_deprecate_positional_args(allowed=['cells'])
    def from_regular_cells(
        cls: type[CellArray],
        cells: MatrixLike[int],
        deep: bool = False,  # noqa: FBT001, FBT002
    ) -> CellArray:
        """Construct a ``CellArray`` from cells which all have the same size.

        Use this method when every cell has the same number of points, for example, an
        array of triangles or an array of quads. The cell offsets are computed
        directly from the cell size, and the input array is used as the
        connectivity array. Use :meth:`from_irregular_cells` instead if the
        cells have varying sizes.

        Parameters
        ----------
        cells : numpy.ndarray or list[list[int]]
            Cell array of shape (``n_cells``, ``cell_size``) where all cells have the same
            ``cell_size``.

        deep : bool, default: False
            Whether to deep copy the cell array data into the vtk connectivity array.
            If ``False``, the returned cell array may share memory with ``cells``.

        Returns
        -------
        pyvista.CellArray
            Constructed ``CellArray``.

        See Also
        --------
        from_irregular_cells
            Equivalent method for cells with varying sizes.
        regular_cells
            Read the cells back as a (n_cells, cell_size) array.

        Examples
        --------
        Create a cell array of two triangles.

        >>> import pyvista as pv
        >>> cells = pv.CellArray.from_regular_cells([[0, 1, 2], [1, 2, 3]])
        >>> cells.n_cells
        2
        >>> cells.regular_cells
        array([[0, 1, 2],
               [1, 2, 3]]...)

        """
        cells = np.asarray(cells)
        n_cells, cell_size = cells.shape
        if cells.dtype != np.int32:
            cells = np.asarray(cells, dtype=pv.ID_TYPE)

        cellarr = cls()
        if _SUPPORTS_FIXED_SIZE_STORAGE:
            cellarr._set_data_fixed_size(cell_size, cells, deep=deep)
        else:
            offsets = cell_size * np.arange(n_cells + 1, dtype=pv.ID_TYPE)
            cellarr._set_data(offsets, cells, deep=deep)
        return cellarr

    @classmethod
    def from_irregular_cells(cls: type[CellArray], cells: MatrixLike[int]) -> CellArray:
        """Construct a ``CellArray`` from cells which may have different sizes.

        Use this method when the cells have varying numbers of points, for example, a
        mix of triangles and quads. The cell offsets are computed from the
        length of each cell, and the connectivity array is built by
        concatenating the cells. Use :meth:`from_regular_cells` instead if all
        cells have the same size.

        Unlike :meth:`from_regular_cells`, this method has no ``deep``
        parameter, since building the connectivity array always makes a copy of
        the input.

        Parameters
        ----------
        cells : Sequence[Sequence[int]]
            Sequence of length ``n_cells`` where each item is a sequence of the
            point indices for that cell. The cells may have different lengths.

        Returns
        -------
        pyvista.CellArray
            Constructed ``CellArray``.

        See Also
        --------
        from_regular_cells
            Equivalent method for cells which all have the same size.
        cell_offsets
            Offsets marking where each cell begins in the connectivity array.

        Examples
        --------
        Create a cell array from a triangle and a quad.

        >>> import pyvista as pv
        >>> cells = pv.CellArray.from_irregular_cells([[0, 1, 2], [1, 2, 3, 4]])
        >>> cells.n_cells
        2
        >>> cells.cell_connectivity
        array([0, 1, 2, 1, 2, 3, 4]...)
        >>> cells.cell_offsets
        array([0, 3, 7]...)

        """
        offsets = np.cumsum([len(c) for c in cells])
        offsets = np.concatenate([[0], offsets], dtype=pv.ID_TYPE)
        connectivity = np.concatenate(cells, dtype=pv.ID_TYPE)
        return cls.from_arrays(offsets, connectivity)  # type: ignore[arg-type]


# The following methods would be much nicer bound to CellArray,
# but then they wouldn't be available on bare vtkCellArrays. In the future,
# consider using vtkCellArray.override decorator, so they're all automatically
# returned as CellArrays


def _get_connectivity_array(cellarr: _vtk.vtkCellArray) -> NumpyArray[int]:
    """Return the array with the point ids that define the cells' connectivity."""
    return _vtk.vtk_to_numpy(cellarr.GetConnectivityArray())


def _get_offset_array(cellarr: _vtk.vtkCellArray) -> NumpyArray[int]:
    """Return the array used to store cell offsets."""
    return _vtk.vtk_to_numpy(cellarr.GetOffsetsArray())


def _get_offsets(cellarr: _vtk.vtkCellArray) -> NumpyArray[int]:
    """Return a read-only array of the cell offsets."""
    array = _get_offset_array(cellarr)
    array.flags['WRITEABLE'] = False
    return array


def _get_connectivity(cellarr: _vtk.vtkCellArray) -> NumpyArray[int]:
    """Return a read-only array of the cell connectivity."""
    array = _get_connectivity_array(cellarr)
    array.flags['WRITEABLE'] = False
    return array


def _validate_offsets_connectivity(
    offsets: NumpyArray[int], connectivity: NumpyArray[int]
) -> None:
    """Raise if ``offsets`` and ``connectivity`` do not describe a valid cell array."""
    for name, array in (('Offsets', offsets), ('Connectivity', connectivity)):
        if array.ndim != 1:
            msg = f'{name} must be a 1D array, got {array.ndim}D.'
            raise ValueError(msg)
        if not np.issubdtype(array.dtype, np.integer):
            msg = f'{name} must have an integer dtype, got {array.dtype}.'
            raise TypeError(msg)

    if offsets.size == 0:
        msg = 'Offsets must have at least one value. Use `[0]` for an empty cell array.'
        raise ValueError(msg)
    if offsets[0] != 0:
        msg = f'The first offset must be 0, got {offsets[0]}.'
        raise ValueError(msg)
    if np.any(np.diff(offsets) < 0):
        msg = 'Offsets must be monotonically non-decreasing.'
        raise ValueError(msg)
    if offsets[-1] != connectivity.size:
        msg = (
            f'The last offset ({offsets[-1]}) must equal the size of the '
            f'connectivity array ({connectivity.size}).'
        )
        raise ValueError(msg)


def _set_cell_array_data(
    cellarr: CellArray,
    offsets: VectorLike[int],
    connectivity: VectorLike[int],
) -> None:
    """Validate ``offsets`` and ``connectivity`` and store them in ``cellarr``.

    The inputs are always deep-copied so the cell array never aliases memory owned by
    the caller. Fixed-size storage is used when the offsets are uniform, which lets VTK
    generate the offsets implicitly instead of allocating them.

    """
    offsets_array = np.asarray(offsets)
    connectivity_array = np.asarray(connectivity)
    # An empty sequence defaults to a float dtype, so coerce it before validating
    if offsets_array.size == 0:
        offsets_array = offsets_array.astype(pv.ID_TYPE)
    if connectivity_array.size == 0:
        connectivity_array = connectivity_array.astype(pv.ID_TYPE)
    _validate_offsets_connectivity(offsets_array, connectivity_array)

    sizes = np.diff(offsets_array)
    uniform = sizes.size > 0 and bool((sizes == sizes[0]).all()) and sizes[0] > 0
    if _SUPPORTS_FIXED_SIZE_STORAGE and uniform:
        cell_size = int(sizes[0])
        cellarr._set_data_fixed_size(
            cell_size, connectivity_array.reshape(-1, cell_size), deep=True
        )
    else:
        cellarr._set_data(offsets_array, connectivity_array, deep=True)


def _make_cell_array(offsets: VectorLike[int], connectivity: VectorLike[int]) -> CellArray:
    """Build a validated :class:`CellArray` from offsets and connectivity."""
    cellarr = CellArray()
    _set_cell_array_data(cellarr, offsets, connectivity)
    return cellarr


def _get_regular_cells(cellarr: _vtk.vtkCellArray) -> NumpyArray[int]:
    """Return a (``n_cells``, cell_size)-shaped array of point indices for equal-sized faces."""
    cells = _get_connectivity_array(cellarr)
    if len(cells) == 0:
        return cells

    if _SUPPORTS_FIXED_SIZE_STORAGE and cellarr.IsStorageFixedSize():
        cell_size = cellarr.IsHomogeneous()
    else:
        offsets = _get_offset_array(cellarr)
        cell_size = offsets[1] - offsets[0]

    try:
        return cells.reshape(-1, cell_size)
    except ValueError:
        offsets = _get_offset_array(cellarr)
        sizes = sorted(np.unique(np.diff(offsets)).tolist())
        msg = (
            f'Cell array does not have regular cells. '
            f'Multiple cell sizes detected with different number of points: {sizes}'
        )
        raise ValueError(msg)


def _get_irregular_cells(cellarr: _vtk.vtkCellArray) -> tuple[NumpyArray[int], ...]:
    """Return a tuple of length ``n_cells`` of each cell's point indices."""
    cells = _get_connectivity_array(cellarr)
    if len(cells) == 0:
        return ()

    offsets = _get_offset_array(cellarr)
    return tuple(np.split(cells, offsets[1:-1]))
