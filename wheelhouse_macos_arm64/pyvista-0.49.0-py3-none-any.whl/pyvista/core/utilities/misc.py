"""Miscellaneous core utilities."""

from __future__ import annotations

from abc import ABCMeta
from collections.abc import Sequence
from enum import Enum
import functools
import importlib
import sys
import threading
import traceback
from typing import TYPE_CHECKING
from typing import Literal
from typing import TypeVar
import warnings

import numpy as np
from typing_extensions import Self

from pyvista import _vtk
from pyvista._warn_external import warn_external
from pyvista.core.utilities.accessor_registry import _resolve_pending_accessor

if TYPE_CHECKING:
    from typing import Any

    from pyvista._typing_core import ArrayLike
    from pyvista._typing_core import NumpyArray
    from pyvista._typing_core import VectorLike

    _T = TypeVar('_T')

T = TypeVar('T', bound='AnnotatedIntEnum')

_SMPBackendOptions = Literal['stdthread', 'tbb', 'openmp', 'sequential']
_SMP_BACKEND_NAMES: dict[str, str] = {
    'stdthread': 'STDThread',
    'tbb': 'TBB',
    'openmp': 'OpenMP',
    'sequential': 'Sequential',
}

if sys.version_info >= (3, 11):
    from enum import StrEnum
else:

    class StrEnum(str, Enum):  # noqa: D101
        def __str__(self) -> str:
            return self.value


def assert_empty_kwargs(**kwargs) -> bool:
    """Assert that all keyword arguments have been used (internal helper).

    If any keyword arguments are passed, a ``TypeError`` is raised.

    Parameters
    ----------
    **kwargs : dict
        Keyword arguments passed to the function.

    Returns
    -------
    bool
        ``True`` when successful.

    Raises
    ------
    TypeError
        If any keyword arguments are passed, a ``TypeError`` is raised.

    """
    n = len(kwargs)
    if n == 0:
        return True
    caller = sys._getframe(1).f_code.co_name
    keys = list(kwargs.keys())
    bad_arguments = ', '.join([f'"{key}"' for key in keys])
    grammar = 'is an invalid keyword argument' if n == 1 else 'are invalid keyword arguments'
    message = f'{bad_arguments} {grammar} for `{caller}`'
    raise TypeError(message)


def check_valid_vector(point: VectorLike[float], name: str = '') -> None:
    """Check if a vector contains three components.

    Parameters
    ----------
    point : VectorLike[float]
        Input vector to check. Must be an iterable with exactly three components.
    name : str, optional
        Name to use in the error messages. If not provided, "Vector" will be used.

    Raises
    ------
    TypeError
        If the input is not an iterable.
    ValueError
        If the input does not have exactly three components.

    """
    if not isinstance(point, (Sequence, np.ndarray)):
        msg = f'{name} must be a length three iterable of floats.'
        raise TypeError(msg)
    if len(point) != 3:
        if name == '':
            name = 'Vector'
        msg = f'{name} must be a length three iterable of floats.'
        raise ValueError(msg)


def abstract_class(cls_):  # noqa: ANN001, ANN201 # numpydoc ignore=RT01
    """Decorate a class, overriding ``__new__``.

    Preventing a class from being instantiated similar to abc.ABCMeta
    but does not require an abstract method.

    Parameters
    ----------
    cls_ : type
        The class to be decorated as abstract.

    """

    def __new__(cls, *args, **kwargs):  # noqa: ANN001, ANN202, ARG001, N807
        if cls is cls_:
            msg = f'{cls.__name__} is an abstract class and may not be instantiated.'
            raise TypeError(msg)
        return super(cls_, cls).__new__(cls)

    cls_.__new__ = __new__
    return cls_


class AnnotatedIntEnum(int, Enum):
    """Annotated enum type."""

    annotation: str

    def __new__(cls, value: int, annotation: str, doc: str | None = None) -> Self:
        """Initialize, optionally attaching a member docstring."""
        obj = int.__new__(cls, value)
        obj._value_ = value
        obj.annotation = annotation
        if doc is not None:
            obj.__doc__ = doc
        return obj

    @classmethod
    def from_str(cls, input_str: str) -> Self:
        """Create an enum member from a string.

        Parameters
        ----------
        input_str : str
            The string representation of the annotation for the enum member.

        Returns
        -------
        AnnotatedIntEnum
            The enum member with the specified annotation.

        Raises
        ------
        ValueError
            If there is no enum member with the specified annotation.

        """
        for value in cls:
            if value.annotation.lower() == input_str.lower():
                return value
        msg = f'{cls.__name__} has no value matching {input_str}'
        raise ValueError(msg)

    @classmethod
    def from_any(cls, value: AnnotatedIntEnum | int | str) -> Self:
        """Create an enum member from a string, int, etc.

        Parameters
        ----------
        value : int | str | AnnotatedIntEnum
            The value used to determine the corresponding enum member.

        Returns
        -------
        AnnotatedIntEnum
            The enum member matching the specified value.

        Raises
        ------
        ValueError
            If there is no enum member matching the specified value.

        """
        if isinstance(value, cls):
            return value
        elif isinstance(value, int):
            return cls(value)  # type: ignore[call-arg]
        elif isinstance(value, str):
            return cls.from_str(value)
        else:
            msg = f'Invalid type {type(value)} for class {cls.__name__}.'  # type: ignore[unreachable]
            raise TypeError(msg)


@functools.cache
def has_module(module_name: str) -> bool:
    """Return if a module can be imported.

    Parameters
    ----------
    module_name : str
        Name of the module to check.

    Returns
    -------
    bool
        ``True`` if the module can be imported, otherwise ``False``.

    """
    module_spec = importlib.util.find_spec(module_name)
    return module_spec is not None


class _SMPToolsContext:
    """Context manager that restores VTK SMP backend state on exit.

    Parameters
    ----------
    original_backend : str
        SMP backend to restore on exit.

    original_threads : int
        Thread count to restore on exit.

    """

    def __init__(self, original_backend: str, original_threads: int) -> None:
        self._original_backend = original_backend
        self._original_threads = original_threads

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *exc_info: object) -> None:
        _vtk.vtkSMPTools.SetBackend(self._original_backend)
        _vtk.vtkSMPTools.Initialize(self._original_threads)


def enable_smp_tools(
    backend: _SMPBackendOptions = 'stdthread',
    n_threads: int | None = None,
) -> _SMPToolsContext:
    """Enable a VTK SMP backend for filters that support shared-memory parallelism.

    VTK's Python wheels currently default to the sequential SMP backend. This
    helper switches to a parallel backend and optionally configures the maximum
    number of threads used by VTK filters that rely on :vtk:`vtkSMPTools`.

    The backend is applied immediately, so calling this function by itself
    enables the chosen backend for the rest of the process. The return value is
    also a context manager, so using it with a ``with`` statement will restore
    the previous backend and thread count on exit.

    Parameters
    ----------
    backend : str, default: 'stdthread'
        SMP backend to enable. Acceptable values are:

        - ``'stdthread'``: Enable VTK's ``std::thread`` backend. This is the
          default and is available in the current VTK wheels.
        - ``'tbb'``: Enable Intel oneTBB when available in the current VTK
          build.
        - ``'openmp'``: Enable OpenMP when available in the current VTK build.
        - ``'sequential'``: Use VTK's sequential backend.

    n_threads : int, optional
        Maximum number of threads to use. If not provided, VTK resets to its
        default maximum thread count and honors the ``VTK_SMP_MAX_THREADS``
        environment variable when it is set.

    Returns
    -------
    contextlib.AbstractContextManager
        A context manager that restores the previous SMP backend and thread
        count when exited. The return value may be discarded when the change
        should apply for the remainder of the process.

    Raises
    ------
    TypeError
        If ``backend`` is not a string or if ``n_threads`` is not an integer.

    ValueError
        If ``backend`` is invalid or if ``n_threads`` is less than ``1``.

    RuntimeError
        If this VTK build does not support runtime SMP backend selection, or if
        the requested backend is unavailable.

    Examples
    --------
    Enable the wheel-supported ``stdthread`` backend for the rest of the
    process.

    >>> import pyvista as pv
    >>> pv.enable_smp_tools()  # doctest:+SKIP

    Configure the backend before running a contour filter.

    >>> from pyvista import examples
    >>> pv.enable_smp_tools(n_threads=8)  # doctest:+SKIP
    >>> grid = examples.download_fea_bracket()  # doctest:+SKIP
    >>> _ = grid.contour(5, scalars='Equivalent Stress')  # doctest:+SKIP

    Scope the backend change to a ``with`` block. The previous backend and
    thread count are restored on exit, even if an exception is raised.

    >>> with pv.enable_smp_tools(n_threads=8):  # doctest:+SKIP
    ...     _ = grid.contour(5, scalars='Equivalent Stress')

    """
    if not isinstance(backend, str):
        msg = '`backend` must be a string.'  # type: ignore[unreachable]
        raise TypeError(msg)

    backend_key = backend.lower()
    vtk_backend = _SMP_BACKEND_NAMES.get(backend_key)
    if vtk_backend is None:
        valid_backends = ', '.join(f'`{name}`' for name in _SMP_BACKEND_NAMES)
        msg = f'Invalid SMP backend `{backend}`. Valid options are: {valid_backends}.'
        raise ValueError(msg)

    if n_threads is not None:
        if isinstance(n_threads, bool) or not isinstance(n_threads, (int, np.integer)):
            msg = '`n_threads` must be an integer.'
            raise TypeError(msg)
        if n_threads < 1:
            msg = '`n_threads` must be greater than or equal to 1.'
            raise ValueError(msg)
        n_threads_ = int(n_threads)
    else:
        n_threads_ = None

    if not hasattr(_vtk, 'vtkSMPTools') or not hasattr(_vtk.vtkSMPTools, 'SetBackend'):
        msg = 'This VTK build does not support runtime SMP backend selection.'
        raise RuntimeError(msg)

    original_backend = _vtk.vtkSMPTools.GetBackend()
    original_threads = _vtk.vtkSMPTools.GetEstimatedNumberOfThreads()

    available = _vtk.vtkSMPTools.SetBackend(vtk_backend)
    if not available:
        _vtk.vtkSMPTools.SetBackend(original_backend)
        _vtk.vtkSMPTools.Initialize(original_threads)
        msg = f'The requested SMP backend `{backend_key}` is not available in this VTK build.'
        raise RuntimeError(msg)

    if n_threads_ is None:
        _vtk.vtkSMPTools.Initialize()
    else:
        _vtk.vtkSMPTools.Initialize(n_threads_)

    return _SMPToolsContext(original_backend, original_threads)


def try_callback(func, *args) -> None:  # noqa: ANN001
    """Wrap a given callback in a try statement.

    Parameters
    ----------
    func : callable
        Callable object.

    *args
        Any arguments.

    """
    try:
        func(*args)
    except Exception:  # noqa: BLE001  # pragma: no cover
        etype, exc, tb = sys.exc_info()
        stack = traceback.extract_tb(tb)[1:]
        formatted_exception = 'Encountered issue in callback (most recent call last):\n' + ''.join(
            traceback.format_list(stack) + traceback.format_exception_only(etype, exc),
        ).rstrip('\n')
        # Force the warning to always be shown. Otherwise, callbacks bound to
        # high-frequency events (e.g. ``MouseMoveEvent``) emit an identical
        # warning at the same call site on every invocation, and Python's
        # default filter de-duplicates it to a single message per session,
        # making callback errors appear to be silently swallowed.
        with warnings.catch_warnings():
            warnings.simplefilter('always')
            warn_external(formatted_exception)


def threaded(fn):  # noqa: ANN001, ANN201
    """Call a function using a thread.

    Parameters
    ----------
    fn : callable
        Callable object.

    Returns
    -------
    function
        Wrapped function.

    """

    def wrapper(*args, **kwargs):  # noqa: ANN202
        thread = threading.Thread(target=fn, args=args, kwargs=kwargs)
        thread.start()
        return thread

    return wrapper


class conditional_decorator:  # noqa: N801
    """Conditional decorator for methods.

    Parameters
    ----------
    dec : callable
        The decorator to be applied conditionally.
    condition : bool
        Condition to match. If ``True``, the decorator is applied. If
        ``False``, the function is returned unchanged.

    """

    def __init__(self, dec, condition) -> None:  # noqa: ANN001
        """Initialize."""
        self.decorator = dec
        self.condition = condition

    def __call__(self, func):  # noqa: ANN001, ANN204
        """Call the decorated function if condition is matched."""
        if not self.condition:
            # Return the function unchanged, not decorated.
            return func
        return self.decorator(func)


def _check_range(value: float, rng: Sequence[float], parm_name: str) -> None:
    """Check if a parameter is within a range."""
    if value < rng[0] or value > rng[1]:
        msg = (
            f'The value {float(value)} for `{parm_name}` is outside the '
            f'acceptable range {tuple(rng)}.'
        )
        raise ValueError(msg)


class _AutoFreezeMeta(type):
    """Metaclass to automatically freeze a class when called."""

    def __call__(cls: type[_T], *args, **kwargs) -> _T:
        obj = super().__call__(*args, **kwargs)  # type: ignore[misc]
        obj._no_new_attributes(cls)
        return obj


class _AutoFreezeABCMeta(_AutoFreezeMeta, ABCMeta):
    """Metaclass to combine automatic attribute freezing with ABC support."""


class _DataObjectMeta(_AutoFreezeABCMeta):
    """Metaclass for ``DataObject`` that resolves accessor entry-points on class access.

    Without this hook, class-level attribute access (for example, ``pv.PolyData.manifold``)
    bypasses lazy loading of ``pyvista.accessors`` entry-point plugins and raises
    ``AttributeError`` until the plugin happens to be imported some other way.
    Instance access is handled by ``DataObject.__getattr__``.
    """

    def __getattr__(cls, name: str) -> Any:
        # Check sys.meta_path to avoid dynamic imports when Python is shutting down
        if sys.meta_path is None:  # pragma: no cover
            return None  # type: ignore[unreachable]

        if _resolve_pending_accessor(name):
            return getattr(cls, name)
        msg = f'type object {cls.__name__!r} has no attribute {name!r}'
        raise AttributeError(msg)


def _allow_ipython_completion(cls: type) -> None:
    """Let IPython's default completion policy evaluate instances of ``cls``.

    IPython's ``limited`` evaluation policy refuses attribute and item access on
    any class that overrides ``__getattribute__`` or ``__getattr__``, which every
    VTK subclass does, unless the exact type is allow-listed. Tab completion such
    as ``mesh.point_data['`` depends on that evaluation.
    """
    if 'IPython' not in sys.modules:
        return
    # IPython 9.17+ loads the completer lazily, so the module has to be imported here
    guarded_eval = importlib.import_module('IPython.core.guarded_eval')
    policy = getattr(guarded_eval, 'EVALUATION_POLICIES', {}).get('limited')
    for name in ('allowed_getattr', 'allowed_getitem'):
        allowed = getattr(policy, name, None)
        if isinstance(allowed, set):
            allowed.add(cls)


class _NoNewAttrMixin(metaclass=_AutoFreezeABCMeta):
    """``Mixin`` to prevent adding new attributes.

    This class is mainly used to prevent users from setting the wrong attributes on an
    object. It freezes the attributes when called and prevents setting new ones via
    "normal" methods like ``obj.foo = 42``.
    """

    def __init_subclass__(cls, **kwargs) -> None:
        """Register each subclass with IPython's completion policy."""
        super().__init_subclass__(**kwargs)
        _allow_ipython_completion(cls)

    def _no_new_attributes(self, this_class: type) -> None:
        """Prevent setting additional attributes."""
        object.__setattr__(self, '__frozen', True)
        object.__setattr__(self, '__frozen_by_class', this_class)

    def _check_new_attribute(self, key: str) -> None:
        """Raise if a frozen instance is given a new attribute it does not allow."""
        # Check sys.meta_path to avoid dynamic imports when Python is shutting down
        if sys.meta_path is not None:
            # Get mode for setting new attributes. Read straight out of the module
            # dict: this runs on every __setattr__, and going through the import
            # machinery (or getattr, which would hit pyvista's module-level
            # __getattr__) is needless overhead. ``pyvista.core`` is imported
            # before ``_ALLOW_NEW_ATTRIBUTES_MODE`` is defined, so a missing key
            # means we are still mid-import: disallow new attributes, as before.
            pyvista_module = sys.modules.get('pyvista')
            _ALLOW_NEW_ATTRIBUTES_MODE = (
                False
                if pyvista_module is None
                else pyvista_module.__dict__.get('_ALLOW_NEW_ATTRIBUTES_MODE', False)
            )

            # Check if setting a new attribute is allowed
            if not (
                _ALLOW_NEW_ATTRIBUTES_MODE is True
                or (key.startswith('_') and _ALLOW_NEW_ATTRIBUTES_MODE == 'private')
            ):
                # Allow attributes that already exist on the instance or anywhere in the MRO
                cls = type(self)
                if key in object.__getattribute__(self, '__dict__'):
                    return
                for base in cls.__mro__:
                    if key in base.__dict__:
                        return

                from pyvista import PyVistaAttributeError  # noqa: PLC0415

                msg = (
                    f'Attribute {key!r} does not exist and cannot be added to class '
                    f'{cls.__name__!r}\nUse `pyvista.set_new_attribute` '
                    f'or `pyvista.allow_new_attributes` to set new attributes.\n'
                    f'Setting new private variables (with `_` prefix) is allowed by default.'
                )
                raise PyVistaAttributeError(msg)

    def __setattr__(self, key: str, value: Any) -> None:
        """Prevent adding new attributes to classes using "normal" methods."""
        # Only check instances frozen by their own class, ignoring parent-set state
        if object.__getattribute__(self, '__dict__').get('__frozen_by_class') is type(self):
            _NoNewAttrMixin._check_new_attribute(self, key)
        object.__setattr__(self, key, value)


def set_new_attribute(obj: object, name: str, value: Any) -> None:
    """Set a new attribute for this object.

    Python allows arbitrarily setting new attributes on objects at any time,
    but PyVista's classes do not allow this. If an attribute is not part of
    PyVista's API, an ``AttributeError`` is normally raised when attempting
    to set it.

    Use :func:`set_new_attribute` to override this and set a new attribute anyway.

    Parameters
    ----------
    obj : object
        Object to set the attribute on.

    name : str
        Attribute name.

    value : Any
        Attribute value.

    See Also
    --------
    pyvista.allow_new_attributes
        Context manager for controlling if setting new attributes is allowed.

    Examples
    --------
    Set a new custom attribute on a mesh.

    >>> import pyvista as pv
    >>> mesh = pv.PolyData()
    >>> pv.set_new_attribute(mesh, 'foo', 42)
    >>> mesh.foo
    42

    This is equivalent to using :data:`allow_new_attributes` with ``True``.

    >>> with pv.allow_new_attributes(True):
    ...     mesh.foo = 42

    .. versionadded:: 0.46

    """
    if hasattr(obj, name):
        from pyvista import PyVistaAttributeError  # noqa: PLC0415

        msg = (
            f'Attribute {name!r} already exists. '
            '`set_new_attribute` can only be used for setting NEW attributes.'
        )
        raise PyVistaAttributeError(msg)
    object.__setattr__(obj, name, value)


def _reciprocal(
    x: ArrayLike[float], tol: float = 1e-8, value_if_division_by_zero: float = 0.0
) -> NumpyArray[float]:
    """Compute the element-wise reciprocal and avoid division by zero.

    The reciprocal of elements with an absolute value less than a
    specified tolerance has the value specified by ``default_if_div_by_zero``.

    Parameters
    ----------
    x : array_like
        Input array.
    tol : float
        Tolerance value. Values smaller than ``tol`` have a reciprocal of zero.
    value_if_division_by_zero : float
        Default value given to values less than ``tol``, that is, the value given if division
        by zero is detected.

    Returns
    -------
    numpy.ndarray
        Element-wise reciprocal of the input.

    """
    x = np.array(x)
    x = x if np.issubdtype(x.dtype, np.floating) else x.astype(float)
    zero = np.abs(x) < tol
    x[~zero] = np.reciprocal(x[~zero])
    x[zero] = value_if_division_by_zero
    return x


class _classproperty(property):  # noqa: N801
    """Read-only class property decorator.

    Use this decorator as an alternative to chaining `@classmethod`
    and `@property` which is deprecated.

    See:
    - https://docs.python.org/library/functions.html#classmethod
    - https://stackoverflow.com/a/13624858

    Examples
    --------
    >>> from pyvista.core.utilities.misc import _classproperty
    >>> class Foo:
    ...     @_classproperty
    ...     def bar(cls): ...

    """

    def __get__(self: property, owner_self: Any, owner_cls: type | None = None) -> Any:
        return self.fget(owner_cls)  # type: ignore[misc]


class _NameMixin:
    """Add a 'name' property to a class.

    .. versionadded:: 0.45

    .. note::
        This class is a private internal implementation detail. It is documented
        solely so that its public members, which are inherited by public classes,
        are visible in the documentation.

    """

    @property
    def name(self) -> str:  # numpydoc ignore=RT01
        """Get or set the unique name identifier used by PyVista."""
        if not hasattr(self, '_name') or self._name is None:
            address = (
                self.GetAddressAsString('')
                if hasattr(self, 'GetAddressAsString')
                else hex(id(self))
            )
            return f'{type(self).__name__}({address})'
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        if not value:
            msg = 'Name must be truthy.'
            raise ValueError(msg)
        object.__setattr__(self, '_name', str(value))


class _BoundsSizeMixin:
    """Add a ``bounds_size`` property to classes which define ``bounds``.

    .. note::
        This class is a private internal implementation detail. It is documented
        solely so that its public members, which are inherited by public classes,
        are visible in the documentation.


    """

    @property
    def bounds_size(self) -> tuple[float, float, float]:
        """Return the size of each axis of the object's bounding box.

        .. versionadded:: 0.46

        Returns
        -------
        tuple[float, float, float]
            Size of each x-y-z axis.

        Examples
        --------
        Get the size of a cube. The cube has edge lengths of ``(1.0, 1.0, 1.0)``
        by default.

        >>> import pyvista as pv
        >>> mesh = pv.Cube()
        >>> mesh.bounds_size
        (1.0, 1.0, 1.0)

        """
        bounds = self.bounds  # type: ignore[attr-defined]
        return (
            bounds.x_max - bounds.x_min,
            bounds.y_max - bounds.y_min,
            bounds.z_max - bounds.z_min,
        )
